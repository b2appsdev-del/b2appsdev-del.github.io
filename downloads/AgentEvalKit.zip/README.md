# Agent Eval Kit

A small, honest evaluation kit for coding agents: 14 concrete tasks, a weighted rubric, a repeatable run
protocol, a report template and an offline scorer. Built for teams that want evidence before trusting an
agent with a real repository — and a regression check after a model, tool or prompt change.

## What is inside

| File | Purpose |
|---|---|
| `index.html` | Preflight checklist + weighted rubric scorer (offline, saves in your browser) |
| `EVAL-PLAN.md` | Environment freezing, run protocol, thresholds, regression cadence |
| `RUBRIC.md` | 6 dimensions with 1/3/5 anchors and default weights |
| `TEST-CASES.md` | 14 tasks: bugfix, tests, refactor, docs, ambiguity, secrets, destructive commands, scope |
| `REPORT-TEMPLATE.md` | Per-evaluation report with run log and verdict |
| `eval-scores.csv` | Editable score table |
| `LICENSE.md` | Usage terms |

## Quick start (15 minutes)

1. Read `EVAL-PLAN.md` §1–2 and decide the question; freeze the environment.
2. Pick 6–14 tasks from `TEST-CASES.md` that resemble your real work.
3. Run each task 2–3 times on a disposable copy — same prompt, same time limit.
4. Score with `RUBRIC.md`, then open `index.html` and enter the averaged scores.
5. Save the weighted result and verdict in `REPORT-TEMPLATE.md` (or `eval-scores.csv`).

The scorer and checklist work offline: open `index.html` in any modern browser. No account, no network.

## What this kit is not

- Not a universal benchmark, certification, or leaderboard.
- Not a guarantee that an agent is safe for production.
- Not a substitute for reviewing diffs and tests yourself.

Results depend on your repo, tasks, environment and time limits. Report them with that context.

## Safety

Use disposable repos and **fake** secrets only. Remove real credentials before running anything. If a real
credential is exposed, stop, rotate it, and follow your incident process.

## License

Personal use by the buyer and inside the buyer's own team; no resale or redistribution. See `LICENSE.md`.

## Support

This is a self-serve digital product. For purchase or delivery issues, use the marketplace support channel
where you bought it. Questions about eval design can be sent to the seller address on the listing.
