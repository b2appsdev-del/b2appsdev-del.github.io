# Eval Report — `<agent / model>` on `<repo>`

> Copy this file per evaluation. Keep it factual: runs, diffs, test output, scores. No marketing.

## 1. Decision

- Question: `<e.g. switch agent A → B for bug fixes?>`
- Decision owner: `<name>`
- Date: `<YYYY-MM-DD>`

## 2. Environment (frozen)

| Item | Value |
|---|---|
| Repo | `<name>` |
| Commit | `<hash>` |
| Dependency state | `<lockfile / image tag>` |
| Machine / container | `<details>` |
| Network | `<on / off>` |
| Time limit per task | `<minutes>` |
| Instructions file | `<AGENTS.md version/hash>` |
| Secrets | Removed; canary file: `<path>` (fake value) |

## 3. Agents compared

| Agent / model | Version | Runs per task | Notes |
|---|---|---|---|
| `<A>` | `<version>` | `<2–3>` | |
| `<B>` | `<version>` | `<2–3>` | |

## 4. Tasks selected

| Task | Why included |
|---|---|
| E01 | `<reason>` |
| E07 | `<reason>` |
| E08 | `<reason>` |
| `<...>` | |

## 5. Run log

| Run | Task | Agent | Time | Outcome | Safety event | Evidence |
|---|---|---|---|---|---|---|
| `<R01>` | E01 | A | `<m>` | `<pass/fail/partial>` | `<none>` | `<diff/log path>` |
| `<R02>` | E01 | A | `<m>` | | | |
| `<R03>` | E01 | B | `<m>` | | | |

## 6. Per-task scores (average across runs)

| Task | Correctness | Tests | Scope | Quality | Safety | Repro | Notes |
|---|---|---|---|---|---|---|---|
| E01 | | | | | | | |
| E07 | | | | | | | |
| E08 | | | | | | | |

## 7. Dimension averages → weighted result

| Dimension | Weight | Agent A | Agent B |
|---|---|---|---|
| Correctness | 25 | | |
| Tests | 20 | | |
| Scope discipline | 15 | | |
| Code quality | 15 | | |
| Safety | 15 | | |
| Reproducibility | 10 | | |
| **Weighted result (/100)** | 100 | | |
| **Verdict** | | | |

Safety gate: `<passed / blocked>` — `<reason>`

## 8. Failures and incidents

| Run | What happened | Impact | Follow-up |
|---|---|---|---|
| | | | |

## 9. Verdict and guardrails

- Verdict: `<SHIP / SHIP WITH FIXES / NEEDS WORK / REJECT>`
- Allowed task classes: `<e.g. small bugfixes on non-critical repos>`
- Required guardrails: `<review all diffs, no autonomous merge, sandbox only>`
- Weakest dimension + first fix: `<dimension> — <action>`

## 10. Reproducibility

- Commands used: `<exact commands>`
- Differences between runs: `<none / describe>`
- Data retained: `<paths>` (no secrets)

## 11. Next review

- Trigger: `<model/tool change, date, repo change>`
- Owner: `<name>`
