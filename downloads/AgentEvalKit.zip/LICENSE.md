# License — Agent Eval Kit

Copyright © 2026 the seller. All rights reserved.

## Granted

- Personal use by the buyer.
- Use inside the buyer's own team and on the buyer's own repositories.
- Adaptation of tasks, rubric and templates for the buyer's internal evaluations.
- Printing and storing copies for the buyer's own use.

## Not granted

- Resale, sublicensing, redistribution or publication of this kit or a derivative as a product.
- Sharing the files publicly or with other teams outside the buyer's organization.
- Claiming the kit is the buyer's original product.
- Removing or altering this license file in redistributed copies that are not permitted anyway.

## No warranty

Provided “as is”, without warranty of any kind. The seller is not liable for decisions made from evaluation
results, for agent behaviour, or for any damage caused by running agents. This kit is not a certification
and does not guarantee safety, correctness or fitness for a particular purpose.

## Responsible use

Run agents only on disposable copies or sandboxes with fake data. You are responsible for commands the
agent executes, for protecting credentials, and for complying with the terms of the agent tools you use.
