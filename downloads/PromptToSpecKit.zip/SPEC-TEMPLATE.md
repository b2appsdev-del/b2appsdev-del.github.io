# Spec Template

Copy this into a document and fill it. A spec is done when a builder can start without a meeting and a reviewer can
tell whether it shipped.

```markdown
# [Project] — Spec

**Status:** draft | reviewed | approved
**Date:** YYYY-MM-DD
**Owner:** [name]
**Readiness:** [%] — ready to review / needs detail / too vague

## Goal
One sentence: who gets what outcome. No adjectives.

## Audience
Who they are, what they use today, and what they will stop doing.

## Problem
What breaks or wastes time today. One or two concrete examples.

## Platform / stack
What exists, what is new, and what must not change.

## Scope — in
R1. [feature, one line]
R2. [feature, one line]
R3. [feature, one line]

## Scope — out
- [tempting feature postponed]
- [adjacent workflow not touched]

## Constraints
- Deadline / budget
- Data rules (what may be stored, where)
- Compatibility, accessibility, offline needs

## Acceptance criteria
AC1. [a check someone can run without asking you]
AC2. [a failure case that must behave well]

## Non-functional defaults
- Errors in plain language with a next step
- Data stays local unless stated
- Keyboard access on the primary flow

## Open questions
- [question + who answers + by when]

## Next step
Which requirement starts first, and what unblocks it.
```

## Rules

- One requirement per line. If a line contains “and”, it is probably two requirements.
- Acceptance criteria are observations, not hopes: “a digest appears by 09:05 with every open ticket counted”.
- Out-of-scope is part of the spec. It prevents silent scope creep.
- Name a number instead of “fast”, “simple” or “robust”.
- Keep it under two pages. Longer specs are read less, not more.
- Version it. Do not silently rewrite an approved spec; add a change note.
