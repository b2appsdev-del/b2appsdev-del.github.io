# Spec Review Checklist

Use this before sending a spec or starting work. Ten minutes here saves a week of rework.

## Goal

- [ ] One sentence, one outcome, no adjectives.
- [ ] Names the user, the change and the current alternative.
- [ ] A stranger could repeat it correctly.

## Scope

- [ ] At least three requirements, one per line.
- [ ] Each requirement is testable or visibly complete.
- [ ] The out-of-scope list is real; it names tempting items you are postponing.
- [ ] Every requirement maps to the goal; no orphans.

## Acceptance

- [ ] At least two criteria a reviewer can run without asking the author.
- [ ] Includes one failure case (bad input, offline, API error).
- [ ] Criteria describe observations, not intentions.

## Constraints and risk

- [ ] Deadline, budget and data rules are stated.
- [ ] Nothing requires a decision that only the builder can make.
- [ ] Legal, privacy or platform limits are named where they apply.

## Ambiguity

- [ ] No “fast”, “simple”, “robust”, “modern”, “seamless” left unmeasured.
- [ ] Pronouns have referents; “it” is not doing load-bearing work.
- [ ] Open questions have an owner and a by-when.

## Readability

- [ ] Under two pages.
- [ ] Versioned with a date; approved changes get a note.
- [ ] The builder has read the out-of-scope list and the open questions.

## Definition of ready

- [ ] Goal, audience, scope in/out, constraints and at least two acceptance criteria are filled.
- [ ] The first requirement to build is named.
- [ ] Questions blocking work are answered or explicitly deferred.

If a box cannot be ticked, the spec is not ready; that is allowed. Say which question unblocks it.
