# Prompt-to-Spec Kit

Turn a rough prompt into a reviewable spec: goal, audience, scope in/out, numbered requirements, constraints,
acceptance criteria and open questions. Single offline HTML file plus a short guide and checklist.

## Files

| File | Purpose |
|---|---|
| `index.html` | Draft fields, readiness score, vague-language linter, spec generator, Markdown export |
| `SPEC-TEMPLATE.md` | Copy-paste spec template and rules |
| `PROMPT-TO-SPEC-GUIDE.md` | The short method: audience, requirements, numbers, review loop |
| `REVIEW-CHECKLIST.md` | Definition of ready before building |
| `README.md` | This file |
| `LICENSE.md` | Usage terms |

## Workflow

1. Load an example or start from your own rough idea.
2. Fill goal, audience, must-haves, out-of-scope, constraints and acceptance criteria.
3. Watch the readiness checks and remove vague adjectives; name numbers instead.
4. Generate the spec, answer the open questions, regenerate.
5. Copy or download the Markdown and review it with the builder using the checklist.

## What it does not do

- It does not call an LLM or the network; every sentence comes from your fields and fixed templates.
- It does not judge whether the idea is worth building, only whether the spec is concrete.
- It does not estimate time or cost.
- It does not replace a technical design or a security review.

## Privacy

Drafts save in this browser's local storage for this file. Nothing is uploaded. Download the Markdown before
switching devices or clearing site data.

## Support

Self-serve digital product. For purchase or delivery issues, use the marketplace support channel where you bought
it.
