# License — Prompt-to-Spec Kit

Copyright © 2026 the seller. All rights reserved.

## Granted

- Personal and internal business use by the buyer.
- Editing the templates, guide and tool for the buyer's own projects.
- Printing and storing copies for the buyer's own team.

## Not granted

- Resale, sublicensing, redistribution or publication of this kit or a derivative as a product or free download.
- Sharing the files with other organisations or the public.
- Removing copyright and presenting the kit as one's own product.

## No warranty

Provided “as is”, without warranty of any kind. The seller is not liable for decisions, scope changes, delays,
losses or disputes arising from use of the kit. Generated specs are drafts written from the buyer's own input and
must be reviewed by the people responsible for the work.
