# From Prompt to Spec

A rough prompt is a wish. A spec is a decision. This guide is the short path between them.

## 1. Say who and what changes

Bad: “Build a tool for invoices.”
Better: “Solo freelancers who invoice 1–10 clients a month can send an invoice in under two minutes and see when
it is paid.”

If you cannot name the person and the change, the rest of the spec will be decoration.

## 2. Turn verbs into requirements

Take each verb in your prompt and make it a line:

- “create an invoice with line items”
- “send it by email”
- “mark it paid manually”

Then ask: what must be true for this line to be accepted? That answer becomes an acceptance criterion.

## 3. Kill adjectives, keep numbers

| Vague | Replace with |
|---|---|
| fast | loads in under 1.5s on a mid-range phone |
| simple | three fields, no account |
| robust | survives an offline reload without losing the draft |
| modern | React 18 + Vite, no UI kit |
| scalable | handles 10,000 rows in the table view |

The linter in the tool flags the common ones and suggests what to measure instead.

## 4. Write the out-of-scope list first

Scope creep starts as “while we are in there”. Name what is postponed before the builder asks. If you cannot
defend leaving it out, it belongs in v1 — and the spec gets bigger on purpose, not by accident.

## 5. Acceptance criteria a stranger can run

- Weak: “works well”.
- Strong: “a failed API call posts a clear error instead of an empty digest”.

Two strong criteria beat ten vague ones.

## 6. Review loop

1. Generate the draft.
2. Answer the open questions; regenerate.
3. Send to the builder with the out-of-scope list visible.
4. Builder marks ambiguities; you answer in the spec, not in chat.
5. Approve with a date. Changes after approval get a change note.

## 7. When to stop specifying

When the next question can only be answered by a prototype, build the smallest slice that answers it (R1 + AC1)
and park the rest. A spec is a tool, not a deliverable.
