# License — Testimonial Collection Kit

Copyright © 2026 the seller. All rights reserved.

## Granted

- Personal use by the buyer.
- Use inside the buyer's own business for collecting and publishing testimonials for the buyer's own products.
- Editing the templates for the buyer's own use.
- Printing and storing copies for the buyer's own records.

## Not granted

- Resale, sublicensing, redistribution or publication of this kit or a derivative as a product or free download.
- Sharing the files with clients, other sellers or the public.
- Removing copyright and presenting the kit as one's own product.

## No warranty; no legal advice

Provided “as is”, without warranty of any kind. The seller is not a lawyer and does not provide legal advice.
Consent and disclosure material is a starting point that must be adapted to the buyer's jurisdiction and
platform rules. The seller is not liable for complaints, takedowns, fines or losses arising from use of the kit.
