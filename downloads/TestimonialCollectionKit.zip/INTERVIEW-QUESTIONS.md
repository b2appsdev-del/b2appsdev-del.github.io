# Interview Questions

Ask two or three, not all of them. The goal is one concrete, quotable sentence — not a compliment.

## The ten-minute script

1. **Before:** “What was happening before you started, in your own words?”
2. **Trigger:** “What made you decide to try this now?”
3. **First use:** “Walk me through the first time you used it.”
4. **Change:** “What changed — hours, numbers, steps or stress?”
5. **Evidence:** “How did you notice? Who else saw it?”
6. **Doubt:** “What almost stopped you from buying?”
7. **Weak spot:** “What is the weakest part, and how do you handle it?”
8. **Alternative:** “What would you have done instead?”
9. **Recommendation:** “If a friend asked whether it was worth the money, what would you say?”
10. **Permission:** “May I quote the exact sentences with your name, company and/or photo?”

## Question bank by purpose

### Specifics
- What was the situation before?
- What exactly changed — hours, numbers, steps or stress?
- What had you tried before, and why did it not work?
- What did you do in the first week?
- What does “better” mean in practice for you?

### Proof
- Which part did you use first, and what did you do with it?
- How long until you noticed a difference?
- What would you tell someone who is unsure whether it is worth it?
- What would have happened if you had not bought it?
- What result can you point to that a sceptic could check?

### Objections
- What almost stopped you from buying?
- What was the weakest part?
- What did you expect that did not happen?
- What would make you stop using it?

### Story
- Walk me through the day you decided to buy.
- What happened in the first week?
- Who else noticed the change?
- When did it become part of your routine?

### Permission (ask separately, in writing)
- May I quote these exact sentences?
- May I use your name and role?
- May I use your company name and logo, or only your first name?
- Would you be comfortable with a photo or a 30-second video?
- For how long may I use it, and where?

## How to turn answers into a quote

- Use their sentences, trimmed for length; do not swap in stronger words.
- Cut only what is repetitive; mark omissions with an ellipsis if meaning could change.
- Send the exact final quote and credit line for approval, even if they already said yes.
- If the quote names a result, keep the context that makes it honest (timeframe, starting point).
- If an answer is vague, ask one follow-up instead of writing the detail yourself.

## What not to do

- Do not lead with “Would you say it changed your life?”.
- Do not offer a discount or gift for a positive rating.
- Do not combine two customers' words into one quote.
- Do not publish a quote after the customer asks you to remove it.
