# Testimonial Collection Kit

An offline workflow for collecting real, usable testimonials: request templates, an interview script that produces
specifics, a consent-aware log, and Markdown/CSV export.

Open `index.html` in a modern browser. No account, no network requests; data stays in your browser.

## Files

| File | Purpose |
|---|---|
| `index.html` | Request builder, 15 interview prompts, testimonial log, exports |
| `REQUEST-TEMPLATES.md` | Request and follow-up messages by situation |
| `INTERVIEW-QUESTIONS.md` | Ten-minute script and question bank |
| `CONSENT-AND-DISCLOSURE.md` | Permission wording, incentives, removal, jurisdiction notes |
| `README.md` | This file |
| `LICENSE.md` | Usage terms |

## Workflow

1. **Log the result you know** — the builder will not invent one for you.
2. **Send a short request** (email or DM), with “no” made easy.
3. **Ask two or three interview questions** if the reply is vague.
4. **Record the quote and permissions** in the log; tick name/company/photo separately.
5. **Send the exact quote and credit line** for approval.
6. **Export approved Markdown** for the page; keep the CSV as your private record.

## What it does not do

- It does not send messages, host a form or connect to a review platform.
- It does not verify that a testimonial is true; that is your responsibility.
- It does not give legal advice. Consent templates are starting points.
- It does not prevent publishing mistakes: the CSV includes unapproved rows for your records — do not publish
  from it.

## Honesty rules

No invented quotes, no merged customers, no rewards for positive ratings, no edits that strengthen a claim. If a
quote is vague, ask a follow-up. If a customer asks you to remove it, remove it.

## Support

Self-serve digital product. For purchase or delivery issues, use the marketplace support channel where you
bought it.
