# Consent, Credit and Disclosure

> Starting points, not legal advice. Testimonial, advertising and privacy rules vary by country and platform.

## Ask for each permission separately

Do not use one “okay to use my feedback?” checkbox for everything. Record, in writing:

1. **Quote** — may I publish these exact sentences?
2. **Name** — full name, first name only, or initials?
3. **Role** — may I say “ops lead at Acme”?
4. **Company** — may I use the company name and logo?
5. **Photo/video** — may I use the image, and where?
6. **Channels** — product page, marketplace listing, social, ads, email?
7. **Duration** — until when, or until they ask to remove it?

A short reply that says “yes, you can use my name” is enough for the name; store the exact message.

## Permission wording you can paste

> I would like to quote the sentences below on [channels] for [duration]. I would credit you as [credit line].
> May I use your name, role/company and photo/video? You can say yes to some parts and no to others, and you can
> ask me to remove it later.

Always show the **final** quote and credit line before publishing. “Yes” to a draft is not “yes” to a rewrite.

## Incentives and disclosure

- Do not condition a reward on a **positive** review. Rewarding any honest review is less problematic than
  rewarding stars, but disclosure may still be required.
- If an incentive exists, disclose it plainly near the testimonial: “Received a [discount] after purchase.”
- Never buy reviews, use review swaps or ask staff/friends to pose as customers.
- Platform rules may ban incentives entirely; check the marketplace you sell on.

## What you may edit

- Trim length, fix obvious typos, remove private information.
- Keep meaning, tone and qualifiers. Do not upgrade “helped” to “transformed”.
- Mark significant cuts with an ellipsis.
- If the edit changes the claim, ask again.

## What not to publish

- Quotes without permission for the elements used.
- Customer names, photos, logos or results without permission.
- Health, financial or legal outcome claims that imply guarantees.
- Testimonials from people who never bought, or from the seller's own accounts.
- A quote after the customer asked you to take it down.

## Removal requests

Remove or anonymise within a reasonable time, confirm in writing, and keep the record. Removing a testimonial is
cheaper than a complaint.

## The log

The kit's testimonial log records name, quote, source, date and the three common permissions (name, company,
photo). The Markdown export includes **only** rows with name permission on; the CSV includes everything for your
own records. That split is deliberate: do not publish from the CSV.

## Jurisdiction notes to check with counsel

- **EU/UK:** privacy rules cover names and photos; legitimate-interest balancing may allow testimonials, but keep
  records and honour objections.
- **US (FTC):** endorsements must be honest and material connections disclosed; atypical results need context.
- **Marketplaces:** each platform has its own rules on incentives, edited quotes and off-platform links.
