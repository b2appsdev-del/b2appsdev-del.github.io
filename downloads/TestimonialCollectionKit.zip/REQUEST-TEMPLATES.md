# Request Templates

Replace `[brackets]` with facts you know. Never send a fill-in-the-blank message that says “your amazing
results” if you cannot name the result. Under 120 words unless the customer asked for detail.

## 1. After a delivery (email)

Subject: A quick favour — your honest take on [product]

Hi [name],

You mentioned [specific result] after using [product]. Would you be open to a short, honest testimonial? What
worked and what did not is equally useful.

If yes, reply with two or three sentences and tell me what I may credit: your name, your company, and whether a
photo or short video is okay.

No pressure to say yes.

Thanks,
[you]

## 2. After a delivery (DM)

Hi [name] — quick ask about [product]. You mentioned [specific result]. Would you write 2–3 sentences I could
quote? Completely fine to say no. If yes, let me know what I may credit (name, company, photo).

— [you]

## 3. LinkedIn (slightly more context)

Hi [name] — hope things are going well. You mentioned [specific result] after [product]. I am collecting a few
honest accounts of what changed. Would you be open to a couple of sentences? Happy to send three short questions
if that is easier. No pressure either way.

— [you]

## 4. Follow-up (no reply, 4–6 days)

Hi [name] — following up once on the testimonial ask. If it is not a fit, just say so and I will close the loop.
If it is, two sentences is plenty.

## 5. Follow-up (they said yes, then went quiet)

Hi [name] — no rush. If writing is the blocker, reply with a voice note or a rough paragraph and I will send back
the exact quote for your approval before anything is published.

## 6. Wake up a vague quote

Thanks — “great product” is kind, but it will not help a stranger decide. Could I ask one thing: what was
happening before, and what changed after? One concrete detail is enough.

## 7. Request a video (low pressure)

If you are comfortable on camera, a 30-second clip on what changed would be useful. Phone quality is fine. If not,
a written quote is equally welcome — no difference in how I use it.

## 8. Request a case study (longer)

Would you be open to a short case study: the situation before, what you did with [product], and the result? I
will draft it from a 15-minute call and send you the full text to correct or reject.

## 9. Referral ask (only after a positive answer)

Glad it helped. Is there one person you think has the same problem? An introduction is optional — I will not
message anyone without your say-so.

## 10. Ask to renew a permission

Your quote from [month] is still on the product page. Is it still accurate, and may I keep using it for another
year? If anything changed, I will update or remove it.

## 11. Ask for the uncomfortable part

Would you be willing to name the weakest part of [product] on the record? An honest limitation makes the rest of
the testimonial credible, and I will publish it alongside the praise.

## 12. Decline of an incentive (keep it clean)

Thanks for offering to write something in exchange for a discount — I would rather not tie a review to a reward.
If you still want to share your experience, it is welcome on its own terms.

## Follow-up rules

- One follow-up, not five. “No” closes the loop.
- Never send a pre-written quote for them to “approve” unless it is built only from their own words.
- Keep the request and the reply; note the permissions in the log.
- If they ask what you will do with it, answer specifically: where it appears, for how long, with what credit.
