# Refund Policy — Template

> **Not legal advice.** Have counsel review the final text. Mandatory consumer rights override anything below.

## Refund policy (editable clause)

You may request a refund within `[N]` day(s) of purchase by emailing `[SUPPORT EMAIL]` with your order
reference and transaction hash.

Refunds are considered for:
- duplicate payments;
- non-delivery of the purchased product or access;
- a product that is materially different from its description.

Where mandatory consumer law provides additional rights, those rights apply and nothing in this policy limits
them.

**Method.** Refunds of crypto payments are issued as a **new on-chain payment**. We cannot reverse the original
transaction. The refund basis is: `[same asset and amount received, minus network fees / fiat value at purchase
converted to the same asset / as agreed in writing]`. The wallet address is provided by the customer; we are not
responsible for funds sent to an incorrectly provided address.

**Fees.** Network fees for the refund payment are borne by `[SELLER / CUSTOMER / SPLIT]`. If fees exceed the
refundable amount, we will tell the customer before sending.

**Timing.** We aim to process approved refunds within `[N]` business day(s) after approval, subject to network
conditions. A refund is complete when the transaction is broadcast and confirmed according to the policy above.

**Exclusions.** `[e.g. change of mind after download/access, where permitted by law]`. List exclusions only
where the law allows them; a lawyer should confirm.

**Evidence.** We may ask for the order reference, transaction hash, payment asset and network. Keep records of
the decision and any refund transaction.

## Refund processing runbook

1. Verify the request is within the window and matches an order.
2. Confirm the payment asset/network and amount received (use the explorer, not the customer's screenshot only).
3. Decide: approve, request more information, or decline with the legal reason.
4. If approved, confirm the refund address and asset **in writing**.
5. Send the refund as a new transaction; record tx hash, amount, fee and date.
6. Reply to the customer with the tx hash and the expected confirmation time.
7. Update the order record; do not delete the original payment trail.

## Underpayment / overpayment

- Underpayment: request the difference or refund the amount received, less network fees. State the threshold.
- Overpayment: refund the excess, less network fees, on request.
- Wrong network: recovery may be impossible; help where you can, but do not promise recovery.

## What not to write

- “All sales are final” without checking whether that is lawful for your buyer and product.
- “Crypto payments cannot be refunded” as a blanket statement — a refund can be sent as a new payment.
- “Refunds at our sole discretion” without acknowledging mandatory rights.
- “We guarantee recovery” for wrong-network payments.
