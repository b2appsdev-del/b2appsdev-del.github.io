# Sales Terms — Template

> **Not legal advice.** Replace bracketed fields, delete the notes, and have a qualified lawyer review the final
> text for your jurisdiction. Mandatory consumer rights cannot be waived in many places.

Last updated: `[YYYY-MM-DD]`

## 1. About us

We are `[LEGAL BUSINESS NAME]`, `[REGISTERED ADDRESS if required]`. These terms apply to purchases made through
`[WEBSITE]`. Contact: `[SUPPORT EMAIL]`.

## 2. Products and delivery

We sell `[PRODUCT TYPE]`. Delivery: `[DELIVERY TIMING]`. Access details are sent to `[DELIVERY METHOD / EMAIL /
ACCOUNT]`. If delivery fails, contact `[SUPPORT EMAIL]` with the order reference.

*Notes:* describe the actual deliverable, not the marketing promise. If access can be delayed (manual review),
say so.

## 3. Prices, assets and payment

Prices are displayed at checkout in `[CURRENCY]`. We accept payment in `[ASSETS AND NETWORKS]`. The amount and
asset are shown at checkout. Customers are responsible for network fees charged by the blockchain and their
wallet or exchange. Prices may change before purchase; the price shown at checkout applies to that order.

*Notes:* list only assets you can actually reconcile. If you auto-convert, say who bears conversion cost.

## 4. Order acceptance and confirmations

A crypto payment is treated as received when the transaction has at least `[N]` confirmation(s) on the relevant
network, as determined by our payment provider or our records. Until then, the order may show as pending. We may
cancel and refund an order if the payment cannot be verified.

*Notes:* match this number to your checkout QA and provider settings.

## 5. Refunds

See `REFUND-POLICY.md` for the full clause. Summary: requests within `[N]` days to `[SUPPORT EMAIL]`; crypto
refunds are issued as a new on-chain payment; mandatory rights apply.

## 6. Underpayments, overpayments and wrong-network payments

See `CRYPTO-PAYMENT-TERMS.md` §3.

## 7. Chargebacks and disputes

Contact `[SUPPORT EMAIL]` before opening a dispute with any payment provider. Crypto transactions are
irreversible; a dispute does not reverse an on-chain payment. Nothing here limits mandatory rights.

## 8. License and acceptable use

Digital products are licensed for `[PERSONAL / INTERNAL BUSINESS]` use as stated in the product. No resale,
redistribution or publication as the buyer's own product. No unlawful use or infringement.

## 9. Liability

To the extent permitted by law, total liability for a claim relating to an order is limited to the amount paid
for that order. No liability for indirect or consequential loss. Nothing excludes liability that cannot be
excluded by law.

*Notes:* a lawyer must confirm enforceability in your jurisdiction.

## 10. Changes

We may update these terms from time to time. The version in force at purchase applies to that purchase.
Material changes are reflected by the update date.

## 11. Governing law and consumer rights

These terms are governed by the laws of `[JURISDICTION]`, without limiting mandatory consumer protections
available in the customer's place of residence.

## 12. Contact

`[SUPPORT EMAIL]`.

---

## Drafting notes (remove before publishing)

- Do not copy another store's terms wholesale; entity, product and refund mechanics differ.
- Keep the checkout page, product page and these terms consistent.
- If you sell to consumers in the EU/UK, check cooling-off rules and the digital-content exception carefully.
- If you sell B2B, check whether consumer wording creates unintended commitments.
- Archive each published version with its date.
