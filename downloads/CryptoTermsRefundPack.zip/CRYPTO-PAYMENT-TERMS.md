# Crypto Payment Terms — Clauses

> **Not legal advice.** These clauses are starting points for counsel to adapt. Rules on payment services,
> consumer protection, sanctions and tax vary widely.

## 1. Assets, networks and fees

We accept `[ASSETS]` on `[NETWORKS]`. The amount and asset are shown at checkout. The customer is responsible
for network fees charged by the blockchain and by their wallet or exchange. Sending a different asset, or the
same asset on a different network, may result in loss; verify before sending.

*Notes:* be explicit about USDT networks (ERC-20 vs TRC-20) if you accept both. Never imply recovery is likely.

## 2. Exchange rate and timing

The amount due is fixed at checkout for `[N]` minutes. If payment is not received within that window, the order
may expire and a new quote may be required. `[Optionally: prices are denominated in USD; the crypto amount is
calculated at checkout by the payment provider.]`

*Notes:* match this to the checkout provider's behaviour. Do not promise a rate you cannot enforce.

## 3. Underpayment, overpayment and wrong-network payments

If less than the required amount is received, we may request the difference or refund the amount received, less
network fees. If more is received, we will refund the excess, less network fees, on request. Payments on the
wrong network may be unrecoverable; we will make reasonable efforts to help but cannot promise recovery.

## 4. Confirmations and order acceptance

A payment is treated as received after `[N]` confirmation(s) on the relevant network. Until then the order may
show as pending. We may cancel and refund an order if the payment cannot be verified. Confirmation thresholds
are set to balance reorg risk and delivery speed.

## 5. Refunds

Crypto refunds are issued as new on-chain payments; the original transaction cannot be reversed. See
`REFUND-POLICY.md` for the basis, fees, timing and address rules.

## 6. Irreversibility and disputes

Crypto transactions are irreversible. A card or platform dispute does not reverse an on-chain payment. Customers
should contact `[SUPPORT EMAIL]` first. Nothing in this section limits mandatory legal rights.

*Notes:* avoid wording that punishes a customer for exercising lawful dispute rights.

## 7. Compliance and sanctions

We may refuse or cancel an order where required by applicable law, sanctions or payment-provider rules. We may
request information necessary to verify a payment or comply with law.

*Notes:* get specific advice on AML/KYC obligations for your size and jurisdiction; do not claim compliance you
do not have.

## 8. Taxes

Customers are responsible for taxes applicable to them. `[If applicable: prices include/exclude VAT/GST.]`
Business customers may request an invoice with the details required by local law.

## 9. Records

We keep order, payment and refund records for `[PERIOD]` to resolve disputes and meet accounting obligations.
See the privacy policy for data handling.

## 10. Contact

`[SUPPORT EMAIL]` with order reference and transaction hash.

## Clause chooser

| Situation | Clause to adapt |
|---|---|
| Fixed price, short quote window | §2 timing |
| Manual payment review | §4 confirmations |
| Refund as new payment | §5 + `REFUND-POLICY.md` |
| USDT on multiple networks | §1 networks |
| B2B only | remove consumer-facing wording; get advice |
| Card + crypto checkout | keep §6 dispute wording; check platform rules |
