# License — Crypto Terms & Refund Pack

Copyright © 2026 the seller. All rights reserved.

## Granted

- Personal use by the buyer.
- Use inside the buyer's own business for the buyer's own store policies.
- Review and adaptation by the buyer's legal counsel.
- Printing and storing copies for the buyer's own use.

## Not granted

- Resale, sublicensing, redistribution or publication of this pack or a derivative as a product.
- Sharing the files publicly or with other businesses outside the buyer's organization.
- Presenting the pack or its output as legal advice from the seller.
- Claiming the pack is lawyer-approved or a compliance certification.

## No legal advice; no warranty

The seller is not a law firm and does not provide legal advice. The pack is provided “as is”, without warranty
of any kind, including fitness for a particular purpose or legal compliance. The seller is not liable for losses,
disputes, fines or damages arising from use of the templates. The buyer is responsible for the final policy and
for obtaining qualified legal review.

## Responsible use

Keep every published claim accurate, preserve mandatory consumer rights, protect customer data, and follow
applicable law, platform rules and payment-provider terms.
