# Lawyer Review Checklist

Hand this list and your generated draft to counsel. It keeps the billable conversation focused on decisions,
not document formatting.

> This checklist is not legal advice and does not create a lawyer-client relationship.

## Business and scope

- [ ] L01 Legal entity name, registered address and contact details are correct
- [ ] L02 Target markets identified; consumer vs business buyers distinguished
- [ ] L03 Product description in the policy matches the actual deliverable and checkout page

## Consumer rights

- [ ] L04 Cooling-off rights and digital-content exceptions checked per market
- [ ] L05 Mandatory rights statement present; no unlawful waiver
- [ ] L06 Refund window and exclusions are lawful where you sell
- [ ] L07 Cancellation/withdrawal mechanics match what support can actually do

## Payments and refunds

- [ ] L08 Refund method is possible with the processor (new on-chain payment and/or fiat)
- [ ] L09 Refund basis (same asset vs fiat value) is disclosed and operationally feasible
- [ ] L10 Network-fee responsibility and under/overpayment rules are stated
- [ ] L11 Confirmation threshold matches the checkout provider's settings
- [ ] L12 Wrong-network wording does not promise recovery
- [ ] L13 Chargeback/dispute wording respects lawful rights and platform rules

## Tax, data and compliance

- [ ] L14 VAT/GST/sales-tax treatment and invoice requirements confirmed with an accountant
- [ ] L15 Privacy policy link and data-retention period are accurate
- [ ] L16 AML/KYC, sanctions and payment-provider obligations assessed for your size
- [ ] L17 Record-keeping period meets accounting and dispute needs

## Publication

- [ ] L18 License and acceptable-use terms match the product and marketplace rules
- [ ] L19 Lawyer reviewed the final text for each jurisdiction you sell to
- [ ] L20 Version and date archived; update process defined for product changes

## Questions to ask counsel (copy into your email)

1. Are our refund window and exclusions enforceable for digital products sold to consumers in `[markets]`?
2. Is our refund-as-new-payment wording sufficient, and who should bear network fees?
3. Does our confirmation threshold create any delivery or consumer-law risk?
4. What entity and tax details must appear on the policy and invoices in `[jurisdiction]`?
5. Do we need additional crypto-specific disclosures or registrations for our volume and model?
6. Are the liability and dispute clauses enforceable as written?

## Record

| Date | Reviewer | Version | Changes requested | Status |
|---|---|---|---|---|
|  |  |  |  |  |
