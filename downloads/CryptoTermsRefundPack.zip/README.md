# Crypto Terms & Refund Pack

Editable sales terms, refund mechanics and crypto-payment clauses for a small merchant, plus an offline policy
draft generator and a lawyer-review checklist.

> **Not legal advice.** Templates only. Have a qualified lawyer review your final policy for your jurisdiction
> and business model. Mandatory consumer rights cannot be waived in many places.

## What is inside

| File | Purpose |
|---|---|
| `index.html` | Policy draft generator (terms + refunds + crypto clauses) + 13-item review checklist |
| `TERMS-TEMPLATE.md` | Full sales-terms template with placeholders and drafting notes |
| `REFUND-POLICY.md` | Refund clause, refund-as-new-payment runbook, under/overpayment rules |
| `CRYPTO-PAYMENT-TERMS.md` | Crypto clauses: assets, confirmations, fees, disputes, sanctions, tax |
| `LAWYER-CHECKLIST.md` | Questions to resolve with counsel before publishing |
| `LICENSE.md` | Usage terms |

## Quick start

1. Open `index.html` and fill your business details, jurisdiction, assets and refund mechanics.
2. Generate the draft and copy it into your editor.
3. Replace remaining placeholders and remove the template note.
4. Work through `LAWYER-CHECKLIST.md` with a qualified lawyer.
5. Publish only the reviewed version; archive it with the date.

The generator is offline; your inputs stay in your browser.

## What this pack does not do

- It does not provide legal advice or certify compliance.
- It does not override mandatory consumer rights.
- It does not guarantee dispute outcomes or recovery of wrong-network payments.
- It does not replace your privacy policy, tax advice or payment-provider terms.

## License

Personal use by the buyer and inside the buyer's own business; no resale or redistribution. See `LICENSE.md`.

## Support

Self-serve digital product. For purchase or delivery issues, use the marketplace support channel where you
bought it.
