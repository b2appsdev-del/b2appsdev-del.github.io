# CSV Fields

Three exports, all generated in the browser. Dates are `YYYY-MM-DD`; amounts are plain decimals with up to 8
decimal places and no thousands separators.

## orders-YYYY-MM-DD.csv

| Column | Meaning |
|---|---|
| `order` | Order ID as shown to the customer |
| `customer` | Handle or email you entered (may be empty) |
| `asset` | BTC, ETH, USDC, USDT or SOL |
| `expected` | Invoice amount |
| `received` | Sum of linked payments |
| `status` | Open, Paid, Underpaid or Overpaid |
| `shortfall` | Filled only when Underpaid |
| `address` | Receive address for that order |
| `date` | Order date |

## payments-YYYY-MM-DD.csv

| Column | Meaning |
|---|---|
| `txid` | Transaction ID exactly as entered |
| `asset` | Asset of the payment |
| `amount` | Amount received |
| `address` | Address the payment went to |
| `date` | Payment date |
| `linked_order` | Order ID, or `unmatched` |

## underpayments-YYYY-MM-DD.csv

| Column | Meaning |
|---|---|
| `order` | Order ID |
| `customer` | Handle or email |
| `asset` | Asset of the order |
| `expected` | Invoice amount |
| `received` | Sum of linked payments |
| `shortfall` | `expected − received` |
| `address` | Address to request the top-up at |

## Notes

- Spreadsheet apps may auto-format long decimals; import as text or set the column to 8 decimals.
- Txids with commas are quoted correctly; they do not normally contain commas.
- The exported CSVs contain only what you typed. The tool does not add prices, fiat values or tax treatment.
- Keep exports private; they can identify customers and wallets.
