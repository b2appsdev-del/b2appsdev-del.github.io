# License — Crypto Invoice Reconciliation Kit

Copyright © 2026 the seller. All rights reserved.

## Granted

- Personal use by the buyer and the buyer's own business.
- Use inside the buyer's own operations, including for the buyer's clients' orders.
- Editing the tool and documents for the buyer's own use.
- Printing and storing copies for the buyer's own records.

## Not granted

- Resale, sublicensing, redistribution or publication of this kit or a derivative as a product or free download.
- Sharing the files with other businesses or the public.
- Removing copyright and presenting the kit as one's own product.

## No warranty; no professional advice

Provided “as is”, without warranty of any kind. The seller is not an accountant, tax adviser or lawyer and does not
provide accounting, tax or legal advice. Reconciliation output depends on the values the buyer enters and is not a
confirmation that a payment settled. The seller is not liable for shortfalls, refunds, losses, tax treatment or
disputes arising from use of the kit.
