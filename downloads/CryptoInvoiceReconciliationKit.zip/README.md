# Crypto Invoice Reconciliation Kit

Match incoming crypto payments to the invoices you sent, spot short payments, and export a clean record. Single
offline HTML file plus a short playbook. No wallet connection, no accounts, no telemetry.

## Files

| File | Purpose |
|---|---|
| `index.html` | Orders, payments, auto-match, underpayment log, CSV exports |
| `MATCHING-RULES.md` | How matching and the 0.5% tolerance work |
| `UNDERPAYMENT-PLAYBOOK.md` | Policy decisions and customer message templates |
| `CSV-FIELDS.md` | Column reference for the three exports |
| `README.md` | This file |
| `LICENSE.md` | Usage terms |

## Workflow

1. Add the order the moment you send the invoice: order id, customer, asset, expected amount, receive address.
2. When the payment lands, add txid, asset, amount and address. The tool links it automatically when asset and
   address match and the amount is within 0.5%.
3. Review unmatched payments. Link them manually only after you have confirmed from the explorer or the customer.
4. Open the underpayments section, copy the draft message, edit the tone, and decide: top-up or absorb.
5. Export CSVs before a break, a handover or a tax review. Keep them private.

## What it does not do

- It does not connect to a wallet, exchange or chain API; you paste values from the explorer.
- It does not convert to fiat, calculate tax, or replace accounting software.
- It does not verify that a txid exists or that funds are confirmed.
- It does not deliver products or send messages.

## Privacy

Data lives in your browser's local storage for this file. Clearing site data or using private browsing loses it;
export before switching devices. Nothing is uploaded.

## Support

Self-serve digital product. For purchase or delivery issues, use the marketplace support channel where you bought
it.

Not accounting, tax or legal advice.
