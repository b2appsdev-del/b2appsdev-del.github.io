# Matching Rules

Read this once and reconciliation stops being guesswork.

## What the tool matches on

1. **Asset** must be identical (BTC ≠ USDT-on-TRON ≠ USDT-on-ETH for this tool; label networks yourself in the
   order id or customer note if you sell the same ticker on several chains).
2. **Address** must be identical, ignoring case. One address per order is the simplest setup.
3. **Amount** decides the quality of the match: within 0.5% counts as paid; more than 0.5% below links as
   underpaid; otherwise the payment stays unmatched for a manual decision.

Tolerance exists for network fees and exchange withdrawal deductions. 0.5% is a default, not a rule; if your
margins cannot absorb it, lower your own threshold when reviewing.

## The 0.5% band

| Paid vs expected | Result |
|---|---|
| no payments linked | Open |
| within ±0.5% | Paid |
| below by more than 0.5% | Underpaid (shortfall shown) |
| above by more than 0.5% | Overpaid |

Received is the sum of all payments linked to an order, so partial payments add up.

## Unmatched payments are normal

- Customer paid from an exchange with fees deducted → amount below the band and address matches → usually linked
  as underpaid.
- Customer used a different address (old invoice, copy error) → unmatched; confirm from the customer or explorer,
  then link manually.
- Two customers paid the same address → candidates share address; the closest amount wins, but verify before
  trusting it.
- Wrong network / wrong asset → unmatched. Do not link it as paid; decide whether to refund or ask for a resend,
  and record the decision in the customer note or a separate support log.

## Manual linking

Every unmatched payment has an order picker. Linking does not change the amount; it changes which order the
payment counts against. Unlink when you picked wrong; delete when the row is a duplicate or a test.

## Housekeeping

- Order ids should be the ones the customer saw. Never rename an order after linking; delete and re-add instead.
- Keep txids exactly as the explorer shows them; duplicates are rejected to prevent double-counting.
- Export CSVs before clearing anything. Clearing is permanent and local only.
- The tool does no fiat conversion and no tax lot tracking. Bring your own records to your accountant.
