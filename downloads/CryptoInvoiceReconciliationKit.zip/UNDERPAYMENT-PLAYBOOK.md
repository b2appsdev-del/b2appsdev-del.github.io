# Underpayment Playbook

A shortfall is a support conversation, not a moral failing. Decide the policy before the first case, then follow it
in the same way for everyone.

## Decide first

1. **Threshold:** below what shortfall do you absorb it? (Fees are often a few dollars; chasing them costs more.)
2. **Top-up vs refund:** do you ask for the remainder, or refund the payment minus fees and cancel the order?
3. **Time limit:** how long do you hold a partially paid order before releasing the item or seat?
4. **Who pays network fees** on the top-up, and on a refund.
5. **Documentation:** where do you record the decision (order ledger, support inbox, incident log).

Write these down. Customer-facing promises should match what you actually do.

## Message templates

**Standard top-up request**
> Hi {name}, payment for order {order id} arrived short by {shortfall} {asset} (received {received} of
> {expected}). Could you send the remaining {shortfall} {asset} to {address}? If a network or exchange fee caused
> this, tell me and we can decide how to handle it.

**Absorb it (no ask)**
> Hi {name}, payment for order {order id} landed slightly under after fees. No action needed — I am marking it as
> paid and delivering as normal.

**Refund instead**
> Hi {name}, the payment for order {order id} arrived short by {shortfall} {asset}. Rather than a second transfer,
> I can refund the received amount to an address you provide (network fees deducted) and cancel the order. Which do
> you prefer?

**Repeated pattern**
> Hi {name}, this is the second short payment on order {order id}. To keep delivery predictable, I will hold the
> order until the balance arrives or refund it. Happy to walk through the fee math if useful.

## Rules of thumb

- Ask once, clearly, with the exact amount and address. Do not send a wall of text.
- Never demand a different asset or network as a “fix” without saying who covers the conversion.
- Do not deliver the full item against a large shortfall hoping the customer tops up later; set the hold before
  shipping.
- Record the shortfall even when you absorb it; patterns matter for pricing and for chargeback responses.
- If the shortfall came from your own invoice error, own it and adjust the order, do not bill the customer for your
  mistake.
- Refund to the sending address where possible; if the customer asks for a different address, confirm in writing.

## Escalation

- Customer disputes the explorer amount → share the txid and the received/expected numbers, not screenshots of
  private data.
- Customer claims they sent the balance but it is not visible → wait for confirmations, then re-check; do not mark
  paid on a pending transaction.
- Abuse or threats → stop the conversation, follow your community/refund policy, keep records.

Not accounting or legal advice; adapt to your jurisdiction and marketplace rules.
