# Personalization — Five Minutes, Not Five Hours

The template is 20% of the email. The first line is the other 80%.

## The 5-minute research pass

For one prospect, check only these:

1. **Their site** — one page the offer touches (pricing, checkout, docs, hiring).
2. **A recent post/talk/update** — something from the last ~90 days.
3. **The role** — confirm they own the problem, not just the company.
4. **One concrete observation** — a fact, not a compliment.
5. **One plausible impact** — in plain language, without invented numbers.

Stop there. If you cannot find an observation, this prospect is not ready.

## Three first-line formulas

| Formula | Pattern | Example |
|---|---|---|
| Observation → impact | “I noticed X; that usually means Y.” | “Your checkout asks for a phone number before payment; that usually adds drop-off on mobile.” |
| Change → question | “You changed X recently — how is Y going?” | “You moved docs to a new domain — did search traffic follow?” |
| Shared context | “We were both at X; your point on Y…” | “Your point about refunds at [event] matched a problem we keep seeing.” |

Avoid: “I love your company”, “Hope you're well”, “I came across your profile”, “Quick question” as the whole
first line.

## Choosing the right template

| Situation | Template |
|---|---|
| You found a real issue | 4. Small audit offer |
| You have a defensible case study | 3. Case-study opener |
| You are unsure who owns it | 8. Wrong-person ask |
| They went quiet after one email | 5. Useful bump |
| They went quiet after two | 6. One-question nudge |
| No reply after the sequence | 7. Clean close |
| Old conversation, new reason | 9. New-reason email |
| Potential partner | 10. Overlap note |
| Local, small business | 11. Local-business email |
| Met at an event | 12. Event follow-up |

## Claims checklist

- Numbers: only if you can show the source or your own record.
- Logos/testimonials: only with permission.
- “We help X” must be true for your actual clients.
- If the recipient asks “prove it”, you should have an answer.

## Tone

- Short sentences. One idea per paragraph.
- No exclamation marks unless you would use them in speech.
- No “revolutionary”, “game-changing”, “synergy”, “circle back”.
- Write like a competent peer, not a vendor.

## What to do with a “no”

Thank them, stop, and record it. Do not re-approach from another address or ask a colleague to forward the
same pitch. A clean no is data: wrong person, wrong timing, or wrong offer.
