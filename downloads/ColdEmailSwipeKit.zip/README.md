# Cold Email Swipe Kit

Twelve ethical, human-sounding B2B cold email templates with a five-minute personalization method, a four-email
sequence and a pre-send checklist. Offline, copy-ready.

## What is inside

| File | Purpose |
|---|---|
| `index.html` | Swipe browser (filter, search, copy) + 12-item pre-send checklist |
| `SWIPE-FILE.md` | All 12 templates in full, with usage notes |
| `PERSONALIZATION.md` | Research pass, first-line formulas, template picker, claims checklist |
| `SEQUENCE.md` | 4-email cadence, deliverability basics, opt-out handling |
| `LICENSE.md` | Usage terms |

## Quick start (15 minutes)

1. Open `index.html`; pick a goal (first contact, follow-up, breakup, referral, re-engage, partner).
2. Copy one template and replace every `[bracket]` with a verified fact.
3. Run the five-minute research pass in `PERSONALIZATION.md`.
4. Follow the timing in `SEQUENCE.md`; stop on any reply.
5. Clear the pre-send checklist before sending.

Works offline. No account, no network, no tracking.

## Scope and honesty

- For small, researched outreach — not purchased lists or bulk blasts.
- No reply, open or revenue guarantees.
- Not legal advice; consent, identification and opt-out rules vary by jurisdiction.
- Every claim in your email must be true and defensible.

## License

Personal use by the buyer and inside the buyer's own business; no resale or redistribution. See `LICENSE.md`.

## Support

Self-serve digital product. For purchase or delivery issues, use the marketplace support channel where you
bought it.
