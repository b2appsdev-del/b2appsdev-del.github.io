# License — Cold Email Swipe Kit

Copyright © 2026 the seller. All rights reserved.

## Granted

- Personal use by the buyer.
- Use inside the buyer's own business for the buyer's own outreach.
- Adaptation of templates and guides for the buyer's own emails.
- Printing and storing copies for the buyer's own use.

## Not granted

- Resale, sublicensing, redistribution or publication of this kit or a derivative as a product.
- Sharing the files publicly or with other businesses outside the buyer's organization.
- Claiming the kit is the buyer's original product.

## No warranty

Provided “as is”, without warranty of any kind. The seller is not liable for replies, meetings, sales, account
restrictions, deliverability problems, legal claims or any damage related to emails the buyer sends. No reply,
open or revenue guarantee is given or implied.

## Not legal advice

This kit is not legal advice. The buyer is responsible for complying with anti-spam, privacy and marketing law
in the relevant jurisdictions, and with email provider and platform terms.

## Responsible use

Send small, relevant, researched emails. Identify yourself honestly, honor opt-outs immediately, and never use
purchased or scraped lists.
