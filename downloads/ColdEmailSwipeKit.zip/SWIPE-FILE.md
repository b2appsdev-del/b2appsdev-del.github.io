# Swipe File — 12 Templates

Replace every `[bracket]` with a verified fact. Keep the body under 120 words. Plain text, no images, one link
maximum.

> Ethical use: targeted, researched outreach only. No purchased lists, no bulk blasts, no fake familiarity.
> Follow local law and platform terms. No template guarantees a reply.

## 1. The specific observation — First contact

**Subject:** `[Company] + [specific thing you noticed]`

```
Hi [Name],

I noticed [specific, verifiable observation about their site/process/post]. [One sentence on why that usually means a problem or an opportunity].

I help [audience] [outcome]. For [Company], that could mean [one concrete, modest example].

Worth a 15-minute look next week?

[Your name]
[Link]
```

Note: the observation must be true and specific. No compliments, no “hope this finds you well”.

## 2. The question-first email — First contact

**Subject:** `Quick question about [topic]`

```
Hi [Name],

Quick question: how are you handling [specific process] at [Company] right now?

I ask because [one sentence of relevant context] and I have seen [common failure mode] in similar teams.

If it is not a priority, no problem — I will not chase it.

[Your name]
```

Note: use when you genuinely want the answer. Do not ask a fake question to bait a reply.

## 3. The case-study opener — First contact

**Subject:** `How [similar company] handled [problem]`

```
Hi [Name],

I worked with [similar company type] on [problem]. They were losing [specific, true cost] because [cause].

We changed [one thing] and they now [measured, verifiable outcome, or omit the number].

I think [Company] may have the same pattern. Would a short call to compare notes be useful?

[Your name]
```

Note: only use a case study you can defend. If you cannot share the number, describe the change instead.

## 4. The small audit offer — First contact

**Subject:** `Found one thing on [Company]'s [page/flow]`

```
Hi [Name],

I spent ten minutes on [specific page/flow] and noticed [one concrete issue]. It likely costs [plain-language impact].

I wrote the details here: [link or paste 3 bullets]. No strings attached.

If you want help fixing it, I do that for [audience]. If not, the notes are yours.

[Your name]
```

Note: give real value without a gate. One issue, clearly explained, beats a generic “audit”.

## 5. The useful bump — Follow-up

**Subject:** `Re: [original subject]`

```
Hi [Name],

Following up once with something useful: [one new link/insight relevant to them].

Still happy to [original ask] if the timing is right. If not, tell me and I will close the loop.

[Your name]
```

Note: add value or do not send. “Just checking in” is not a follow-up.

## 6. The one-question nudge — Follow-up

**Subject:** `Re: [original subject]`

```
Hi [Name],

One question before I close this out: is [problem] something you are working on this quarter, or is it parked?

Either answer helps me stop guessing.

[Your name]
```

Note: use after 4–6 business days. It invites a real no, which is better than silence.

## 7. The clean close — Breakup

**Subject:** `Closing the loop`

```
Hi [Name],

I have not heard back, so I will assume this is not a priority and stop emailing.

If that changes, reply anytime and I will pick it up. Either way, thanks for the time.

[Your name]
```

Note: send once, then actually stop. A fake breakup followed by more emails destroys trust.

## 8. The wrong-person ask — Referral

**Subject:** `Wrong person?`

```
Hi [Name],

I may have the wrong person — I am looking for whoever owns [specific area] at [Company].

If that is you, [one-sentence offer]. If not, could you point me to the right colleague?

Thanks either way.

[Your name]
```

Note: make it easy to redirect. Do not ask them to forward a pitch.

## 9. The new-reason email — Re-engage

**Subject:** `New since we last spoke`

```
Hi [Name],

We spoke [timeframe] about [topic] and it was not a fit then.

Since then, [one concrete change: new capability, new result, new constraint]. If [problem] is still on your list, I would be glad to revisit. If not, ignore this.

[Your name]
```

Note: you need a real reason. “Following up” after months is not a reason.

## 10. The overlap note — Partner

**Subject:** `Possible overlap between [you] and [them]`

```
Hi [Name],

Your work on [specific thing] overlaps with what my clients ask for: [specific need].

I am not pitching a partnership in the abstract. One example: [concrete scenario where you would refer each other].

Worth a short call to see if it makes sense for both sides?

[Your name]
```

Note: lead with what they get. Do not ask for “a quick chat to explore synergies”.

## 11. The local-business email — First contact

**Subject:** `One small thing on [Company]'s site`

```
Hi [Name],

I was looking at [local business] because [real reason], and noticed [specific issue — e.g. hours/menu/booking link].

It is a small fix, but it may cost you [plain impact]. I do [service] for local businesses and can send the details if useful.

No pressure either way.

[Your name]
```

Note: use for genuinely local, small-number outreach. Check whether unsolicited email is permitted in your area.

## 12. The event follow-up — First contact

**Subject:** `After [event] — [topic]`

```
Hi [Name],

We both attended [session] at [event]. Your point about [specific thing] stuck with me.

I work on [same area] and have been testing [specific approach]. If you are open to comparing notes, I would value your take.

[Your name]
```

Note: specific context only. “Great meeting you” without a detail is instantly forgettable.

## Editing rules

1. Cut the first sentence if it is about you.
2. One ask per email.
3. Replace every bracket; a leftover `[Name]` is an instant delete.
4. Read it aloud; if it sounds like a brochure, rewrite it.
5. If you would not say it to their face, do not send it.
