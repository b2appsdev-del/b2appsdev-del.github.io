# Sequence & Deliverability — Small, Clean Outreach

This is a cadence for **targeted** outreach (tens of emails, not thousands). It is not a bulk-mail playbook.

> Rules on consent, identification and opt-out differ by country and platform. Check the law where you and the
> recipient are, and your email provider's terms. This is not legal advice.

## 4-email sequence

| Step | When | Template | Goal |
|---|---|---|---|
| 1 | Day 0 | 1, 2, 3, 4, 11 or 12 | Earn a reply with one specific observation |
| 2 | Day 4–6 | 5. Useful bump | Add one new useful thing |
| 3 | Day 10–12 | 6. One-question nudge | Invite a clear yes/no |
| 4 | Day 18–21 | 7. Clean close | Close the loop, stop |

Rules:
- One thread, same subject (`Re:`), no new angles invented to keep the thread alive.
- Stop on any reply, including “not now”.
- No more than one email per prospect per week.
- If step 4 gets no reply, stop. Do not restart with a “new” sequence.

## Before the first send

- Use a real name, a real reply-to address and a signature that identifies you.
- Keep volume low and consistent; sudden spikes look like spam.
- Warm the domain: send normal email for a week before outreach, and avoid new domains for large sends.
- Keep links to one; no attachments on first contact.
- Plain text or simple HTML. No tracking pixels unless you have a lawful basis and a reason.
- Include an easy opt-out line if required where you operate.

## Deliverability basics

| Signal | Practical step |
|---|---|
| Authentication | SPF, DKIM and DMARC configured for your domain |
| Reputation | Low volume, high relevance, quick opt-out handling |
| Content | No misleading subject, no link shorteners, no giant images |
| List quality | Only people you researched; no scraped or purchased lists |
| Consistency | Same sending domain; do not rotate domains to evade limits |

## Opt-out handling

Honor any request immediately and across your records. Do not ask “are you sure?”. Do not move the address to
another campaign. Keep a suppression list and check it before every send.

## What this kit will not do

- It will not guarantee opens, replies or meetings.
- It will not make a purchased list acceptable.
- It will not replace legal advice on consent and privacy.
- It will not fix an offer nobody needs.
