(function () {
  "use strict";

  var MP = {};
  var q = function (s, el) { return (el || document).querySelector(s); };
  var qa = function (s, el) { return Array.prototype.slice.call((el || document).querySelectorAll(s)); };

  MP.toast = function (message, opts) {
    opts = opts || {};
    var type = opts.type || "info";
    var duration = opts.duration == null ? 2600 : opts.duration;
    var wrap = q(".mp-toasts");
    if (!wrap) {
      wrap = document.createElement("div");
      wrap.className = "mp-toasts";
      wrap.setAttribute("role", "status");
      wrap.setAttribute("aria-live", "polite");
      document.body.appendChild(wrap);
    }
    var t = document.createElement("div");
    t.className = "mp-toast mp-toast--" + type;
    t.textContent = message;
    wrap.appendChild(t);
    requestAnimationFrame(function () { t.classList.add("mp-show"); });
    setTimeout(function () {
      t.classList.remove("mp-show");
      setTimeout(function () { t.remove(); }, 250);
    }, duration);
  };

  MP.modal = function (opts) {
    opts = opts || {};
    var prevFocus = document.activeElement;
    var overlay = document.createElement("div");
    overlay.className = "mp-overlay";
    overlay.innerHTML =
      '<div class="mp-modal" role="dialog" aria-modal="true">' +
        '<button class="mp-modal__x" aria-label="Close">\u00d7</button>' +
        (opts.title ? '<h3 class="mp-modal__title"></h3>' : "") +
        '<div class="mp-modal__body"></div>' +
        '<div class="mp-modal__actions"></div>' +
      "</div>";
    if (opts.title) q(".mp-modal__title", overlay).textContent = opts.title;
    else q(".mp-modal", overlay).setAttribute("aria-label", opts.ariaLabel || "Dialog");
    q(".mp-modal__body", overlay).innerHTML = opts.body || "";

    var actionsEl = q(".mp-modal__actions", overlay);
    (opts.actions || []).forEach(function (a) {
      var b = document.createElement("button");
      b.className = "mp-btn " + (a.variant ? "mp-btn--" + a.variant : "mp-btn--primary");
      b.textContent = a.label;
      b.addEventListener("click", function () {
        if (typeof a.onClick === "function") a.onClick(close); else close();
      });
      actionsEl.appendChild(b);
    });

    document.body.appendChild(overlay);
    var closeBtn = q(".mp-modal__x", overlay);
    if (closeBtn) closeBtn.focus();
    requestAnimationFrame(function () {
      overlay.classList.add("mp-show");
      if (closeBtn) closeBtn.focus();
    });

    function close() {
      overlay.classList.remove("mp-show");
      setTimeout(function () { overlay.remove(); }, 200);
      if (prevFocus && typeof prevFocus.focus === "function") {
        try { prevFocus.focus(); } catch (e) {}
      }
      if (typeof opts.onClose === "function") opts.onClose();
    }

    if (closeBtn) closeBtn.addEventListener("click", close);
    overlay.addEventListener("click", function (e) { if (e.target === overlay) close(); });
    document.addEventListener("keydown", function onEsc(e) {
      if (e.key === "Escape") { close(); document.removeEventListener("keydown", onEsc); }
    });

    return { close: close };
  };

  function setupTabs(container) {
    if (container.dataset.mpReady) return;
    container.dataset.mpReady = "1";
    var btns = qa("[data-mp-tab]", container);
    var panels = qa("[data-mp-panel]", container);
    var tablist = q(".mp-tabs", container);
    if (tablist) tablist.setAttribute("role", "tablist");
    btns.forEach(function (b) { b.setAttribute("role", "tab"); });
    panels.forEach(function (p) { p.setAttribute("role", "tabpanel"); });
    function show(id) {
      btns.forEach(function (b) {
        var on = b.dataset.mpTab === id;
        b.classList.toggle("active", on);
        b.setAttribute("aria-selected", on ? "true" : "false");
      });
      panels.forEach(function (p) { p.hidden = p.dataset.mpPanel !== id; });
    }
    btns.forEach(function (b) {
      b.addEventListener("click", function () { show(b.dataset.mpTab); });
    });
    if (btns[0]) show(btns[0].dataset.mpTab);
  }

  function setupAccordion(container) {
    if (container.dataset.mpReady) return;
    container.dataset.mpReady = "1";
    qa("[data-mp-acc]", container).forEach(function (btn) {
      var body = btn.nextElementSibling;
      btn.setAttribute("aria-expanded", "false");
      btn.addEventListener("click", function () {
        var open = btn.classList.toggle("active");
        btn.setAttribute("aria-expanded", open ? "true" : "false");
        if (body) body.classList.toggle("open", open);
      });
    });
  }

  function setupDropdown(container) {
    if (container.dataset.mpReady) return;
    container.dataset.mpReady = "1";
    var trigger = q("[data-mp-dropdown-trigger]", container);
    if (!trigger) return;
    trigger.setAttribute("aria-haspopup", "true");
    trigger.setAttribute("aria-expanded", "false");
    function setOpen(open) {
      container.classList.toggle("mp-open", open);
      trigger.setAttribute("aria-expanded", open ? "true" : "false");
    }
    trigger.addEventListener("click", function (e) {
      e.stopPropagation();
      setOpen(!container.classList.contains("mp-open"));
    });
    document.addEventListener("click", function () { setOpen(false); });
  }

  function setupTooltip(el) {
    if (el.dataset.mpReady) return;
    el.dataset.mpReady = "1";
    var tip = document.createElement("span");
    tip.className = "mp-tip";
    tip.textContent = el.dataset.mpTooltip || "";
    el.classList.add("mp-tip-host");
    el.appendChild(tip);
  }

  function setupCountdown(el) {
    if (el.dataset.mpReady) return;
    el.dataset.mpReady = "1";
    var target = new Date(el.dataset.mpCountdown).getTime();
    if (isNaN(target)) { el.textContent = "\u2014"; return; }
    function tick() {
      var diff = target - Date.now();
      if (diff <= 0) { el.textContent = "\u0388\u03bb\u03b7\u03be\u03b5"; return; }
      var d = Math.floor(diff / 86400000);
      var h = Math.floor((diff % 86400000) / 3600000);
      var m = Math.floor((diff % 3600000) / 60000);
      var s = Math.floor((diff % 60000) / 1000);
      var pad = function (n) { return String(n).padStart(2, "0"); };
      el.textContent = d + "\u03b7 " + pad(h) + ":" + pad(m) + ":" + pad(s);
    }
    tick();
    setInterval(tick, 1000);
  }

  function setupCopy(el) {
    if (el.dataset.mpReady) return;
    el.dataset.mpReady = "1";
    el.addEventListener("click", function () {
      var text = el.dataset.mpCopy || el.textContent;
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(function () {
          MP.toast("\u0391\u03bd\u03c4\u03b9\u03b3\u03c1\u03ac\u03c6\u03b7\u03ba\u03b5!", { type: "success" });
        }).catch(function () {
          MP.toast("\u0391\u03c0\u03bf\u03c4\u03c5\u03c7\u03af\u03b1 \u03b1\u03bd\u03c4\u03b9\u03b3\u03c1\u03b1\u03c6\u03ae\u03c2", { type: "error" });
        });
      } else {
        MP.toast("\u0391\u03c0\u03bf\u03c4\u03c5\u03c7\u03af\u03b1 \u03b1\u03bd\u03c4\u03b9\u03b3\u03c1\u03b1\u03c6\u03ae\u03c2", { type: "error" });
      }
    });
  }

  function setupTheme(el) {
    if (el.dataset.mpReady) return;
    el.dataset.mpReady = "1";
    var KEY = "mp-theme";
    function apply(light) {
      document.documentElement.classList.toggle("mp-light", light);
      el.textContent = light ? "\u2600\ufe0f Light" : "\ud83c\udf19 Dark";
    }
    var saved = null;
    try { saved = localStorage.getItem(KEY); } catch (e) {}
    apply(saved === "light");
    el.addEventListener("click", function () {
      var light = !document.documentElement.classList.contains("mp-light");
      apply(light);
      try { localStorage.setItem(KEY, light ? "light" : "dark"); } catch (e) {}
    });
  }

  function setupValidate(form) {
    if (form.dataset.mpReady) return;
    form.dataset.mpReady = "1";
    qa("[required]", form).forEach(function (f) {
      f.addEventListener("input", function () {
        f.classList.remove("mp-invalid");
        f.removeAttribute("aria-invalid");
      });
    });
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var ok = true;
      qa("[required]", form).forEach(function (f) {
        var invalid = !String(f.value || "").trim();
        if (!invalid && f.type === "email") {
          invalid = !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(f.value);
        }
        f.classList.toggle("mp-invalid", invalid);
        f.setAttribute("aria-invalid", invalid ? "true" : "false");
        if (invalid) ok = false;
      });
      if (ok) {
        MP.toast("\u0395\u03c0\u03b9\u03c4\u03c5\u03c7\u03af\u03b1!", { type: "success" });
        form.reset();
      } else {
        MP.toast("\u03a3\u03c5\u03bc\u03c0\u03bb\u03ae\u03c1\u03c9\u03c3\u03b5 \u03c4\u03b1 \u03c0\u03b5\u03b4\u03af\u03b1", { type: "error" });
      }
    });
  }

  MP.init = function (root) {
    root = root || document;
    qa("[data-mp-tabs]", root).forEach(setupTabs);
    qa("[data-mp-accordion]", root).forEach(setupAccordion);
    qa("[data-mp-dropdown]", root).forEach(setupDropdown);
    qa("[data-mp-tooltip]", root).forEach(setupTooltip);
    qa("[data-mp-countdown]", root).forEach(setupCountdown);
    qa("[data-mp-copy]", root).forEach(setupCopy);
    qa("[data-mp-theme]", root).forEach(setupTheme);
    qa("[data-mp-validate]", root).forEach(setupValidate);
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () { MP.init(); });
  } else {
    MP.init();
  }

  window.MP = MP;
})();
