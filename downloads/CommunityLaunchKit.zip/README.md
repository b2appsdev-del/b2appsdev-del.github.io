# Paid Community Launch Kit

A 30-day launch plan, a break-even pricing calculator and an onboarding sequence for creators opening a
paid community. Purpose: plan the offer, price it honestly, and give members a first win in week one.

Offline. Single HTML file for the interactive parts. No signup, no tracking, no external requests.

## What's inside

| File | Use it for |
|---|---|
| `index.html` | Start here. Plan summary, break-even calculator, 30-item checklist, license |
| `LAUNCH-PLAN.md` | 30-day plan by phase, with tasks and exit criteria |
| `PRICING.md` | Tiers, fees, break-even, monthly vs annual, when to raise |
| `ONBOARDING.md` | First hour, first 7 days, first 30 days, churn-save sequence |
| `PAGE-COPY.md` | Fill-in page/listing/tier/FAQ templates |
| `pricing-model.csv` | Editable pricing inputs and formula rows |
| `README.md` | This file |
| `LICENSE.md` | Personal-use license and disclaimer |

## Quick start (5 minutes)

1. Unzip the folder somewhere you can keep it.
2. Open `index.html` in any modern browser. Everything works offline.
3. Read the 30-day plan summary, then open `LAUNCH-PLAN.md` and copy the tasks into your tracker.
4. Put your real costs and fees into the calculator. Write the result in `pricing-model.csv`.
5. Draft your page with `PAGE-COPY.md` and prepare `ONBOARDING.md` before launch day.
6. Tick items in `index.html` as you go; ticks save in that browser. Print if you prefer paper.

## How to adapt it

- Set your own first-win milestone in `ONBOARDING.md`; everything else should point to it.
- Replace every bracketed field in `PAGE-COPY.md`; the examples are examples, not claims.
- Use your platform's real fee schedule; percentages in the kit are inputs, not facts.
- Keep the boundaries and refund policy in plain language on the page.

## What this is not

- Not a guarantee of members, revenue or retention.
- Not legal, tax or financial advice.
- Not a moderation playbook or a full course; it is a launch and onboarding kit.
- Not a substitute for talking to your audience before you build.

## License

See `LICENSE.md`: personal use by the buyer and inside the buyer's own community business; **no resale or
redistribution** of the kit itself.
