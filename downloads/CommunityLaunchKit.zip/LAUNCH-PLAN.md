# 30-Day Launch Plan — Paid Community

Companion to `index.html` (checklist IDs C01–C30), `PRICING.md`, `ONBOARDING.md` and `PAGE-COPY.md`.

> No guarantees. This plan is a sequence of decisions and tasks. Results depend on your audience,
> your offer and your execution. Adjust dates to your real calendar.

## Phase 0 — Validate (days −30 to −24)

**Goal:** confirm people will pay for this specific outcome before you build a room.

| Day | Task | Output |
|---|---|---|
| −30 | Write the outcome in one sentence a stranger understands | One-sentence promise |
| −29 | List 20 people who might have the problem | Outreach list |
| −28 | Talk to 5 of them; ask what they tried and what it cost them | Notes in their words |
| −27 | Talk to 5 more; do not pitch yet | Notes |
| −26 | Ask for a soft commitment (email, “I would pay $X”) | Real commitments |
| −25 | Check current alternatives and why people would switch | Short competitor notes |
| −24 | Decide: continue, change the promise, or stop | Written decision |

**Exit criteria:** at least 10 real conversations or a waitlist with human replies (not inflated sign-ups),
and a stop rule you are willing to honour.

## Phase 1 — Build the offer (days −23 to −16)

**Goal:** a clear promise, a small set of tiers and boundaries you can keep.

| Day | Task | Output |
|---|---|---|
| −23 | Define format and cadence: what happens weekly, what members get | Weekly rhythm |
| −22 | List what is **not** included (support limits, response time) | Boundaries |
| −21 | Draft 2–3 tiers and what each unlocks | Tier table |
| −20 | Run the break-even calculator with real costs and fees | Price floor |
| −19 | Set launch price and founding-member offer (real deadline or none) | Pricing decision |
| −18 | Write refund and cancellation policy in plain language | Policy text |
| −17 | Write the first 4 weeks of content/session topics | Content calendar |
| −16 | Show the offer to 3 people from Phase 0; revise once | Revised offer |

**Exit criteria:** one-sentence offer, final tier table, price you can defend, policy text.

## Phase 2 — Pre-launch (days −15 to −8)

**Goal:** a working page, payment and onboarding — tested end-to-end.

| Day | Task | Output |
|---|---|---|
| −15 | Write the community page using `PAGE-COPY.md` | Page draft |
| −14 | Set up payment and access; connect platform roles | Working setup |
| −13 | Run a real test purchase and complete onboarding as a member | Test notes |
| −12 | Prepare the welcome post and first-week messages | Onboarding ready |
| −11 | Seed 3–5 starter threads so the room is not empty | Seeded posts |
| −10 | Invite a small founding group personally | 3–10 founding members |
| −9 | Onboard founding members by hand; watch where they get stuck | Fix list |
| −8 | Fix blockers; publish the final page | Launch-ready page |

**Exit criteria:** a real test purchase works, the first member has a clear next step, and the room has
content before launch day.

## Phase 3 — Launch week (days −7 to 0)

**Goal:** open the doors and personally onboard the first members.

| Day | Task | Output |
|---|---|---|
| −7 | Announce to your list/channels with the launch message | Launch sent |
| −6 | Greet every new member within 24 hours | Greeting log |
| −5 | Run the first live session or publish the first resource | First touchpoint |
| −4 | Ask 3 members what almost stopped them joining | Objection notes |
| −3 | Fix genuine page blockers; do not invent urgency | Updated page |
| −2 | Check payment/access/onboarding for every member | QA pass |
| −1 | Prepare renewal expectations (what month two includes) | Month-two promise |
| 0 | Launch retro: what worked, what to change | Short retro |

**Exit criteria:** first members are active (posted, attended or completed a step), not just joined.

## Phase 4 — First 30 days (days +1 to +30)

**Goal:** activation, rhythm, retention and honest numbers.

| Week | Focus | Tasks |
|---|---|---|
| Week 1 | Activation | Track first-win milestone; greet; one live touchpoint; ask one easy question |
| Week 2 | Rhythm | Publish on schedule; interview 3 active + 3 quiet members; fix the top friction |
| Week 3 | Value proof | Collect a member story (with permission); improve one resource; check costs |
| Week 4 | Renewal | Send churn-save before renewal; review pricing model; write the monthly retro |

**Exit criteria:** a defined first-win milestone exists, members reach it, and you know your real activation
rate and net revenue per member.

## Ongoing monthly loop

1. One retro (what worked, what to cut, next promise).
2. One pricing/cost check against `pricing-model.csv`.
3. One onboarding improvement based on where new members get stuck.
4. One member story (with permission; never invent one).
