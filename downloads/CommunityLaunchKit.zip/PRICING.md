# Pricing a Paid Community

Companion to `pricing-model.csv` and the calculator in `index.html`.

> This is arithmetic and decision guidance, not financial advice. Use your real costs and fees.

## 1. The only formula you need

```
net per member   = price × (1 − fees%) − variable cost per member
break-even       = fixed monthly costs ÷ net per member        (round up)
profit at N      = N × net per member − fixed monthly costs
```

- **Fixed costs:** platform plan, tools, hosting, editing, your baseline time cost if you track it.
- **Variable cost:** anything that grows per member (fulfilment, shipping, per-seat tools).
- **Fees:** payment + platform percentage. Check the provider before every launch.

## 2. Worked example (example numbers only)

| Input | Value |
|---|---|
| Monthly price | $29.00 |
| Fees | 5% |
| Variable cost / member | $2.00 |
| Fixed monthly costs | $60.00 |

- Net per member = 29 × 0.95 − 2 = **$25.55**
- Break-even = 60 ÷ 25.55 = 2.35 → **3 members**
- Target profit $1,000 → (60 + 1000) ÷ 25.55 = 41.49 → **42 members**
- At 25 members → 25 × 25.55 − 60 = **$578.75** monthly profit

These are arithmetic outcomes, not forecasts.

## 3. Choosing a price

1. Start from break-even: the lowest price is not the goal, a sustainable margin is.
2. Price the **outcome**, not the number of posts. Members pay for progress.
3. Keep tiers few (2–3). Each tier must unlock something concrete.
4. Test willingness to pay in Phase 0 (“I would pay $X”), not after launch.

## 4. Monthly vs annual

- Annual plans trade a discount for cash up front.
- A common framing is “two months free” (e.g. $290/year vs $29/month). Decide deliberately.
- Only sell annual if you can credibly deliver for 12 months.
- Annual changes your break-even: you receive the cash once but owe delivery all year.

## 5. Founding-member offers

- Use a **real** deadline and a **real** reason (limited onboarding capacity, early content).
- If the deadline slips, the offer was fake. Do not repeat that.
- A founding price that you cannot sustain creates churn at the first renewal. Cap the number of seats if
  the discount is permanent.

## 6. When to raise the price

- After a clear improvement (new resources, live sessions, better onboarding).
- For **new** members first; grandfather existing members or announce a date.
- Tell people what changed; do not hide it in a footer.

## 7. Common pricing mistakes

- Pricing below break-even because “it is only the start”.
- Too many tiers that confuse the choice.
- Fake scarcity and countdowns that reset — it destroys trust and invites refunds.
- Ignoring fees and refunds when computing net revenue.
- Never reviewing costs as tools and seats grow.

## 8. Quarterly check

Re-run the model every quarter or whenever you change platform, price, or team size. Update
`pricing-model.csv`, then update your page so price and deliverables stay accurate.
