# Onboarding Sequence — Paid Community

Companion to `LAUNCH-PLAN.md`. Goal: every new member reaches a **first win** in week one, so month two
is about progress, not reminders.

> Replace bracketed fields with your own. Never invent member stories or results.

## 1. Define the first win

Write one sentence: “A new member has succeeded when they ______.”

Examples (choose one, replace the blank):
- posted an introduction and got one reply;
- completed the first lesson and left one comment;
- shipped one small task and shared the result;
- booked or attended one live session.

Put that sentence on the page, in the welcome post, and in your own notes.

## 2. First hour (automated or manual)

1. **Welcome message** (email or platform DM):

   > Welcome, [name]. Here is the one thing to do first: [first win]. It takes about [X] minutes.
   > If you get stuck, reply to this message — I read them.

2. **Welcome post** in the community:

   > Welcome, [name]! 👋
   > What brings you here: [their goal]?
   > Start with this: [link to start-here].

3. **Start-here post** pinned with:
   - the promise and weekly rhythm,
   - the first-win step,
   - how to get help and expected response time,
   - what is not included.

4. **Seed content:** 3–5 threads or resources already exist so the room is not empty.

## 3. First 7 days

| Day | Message / action | Purpose |
|---|---|---|
| 1 | Personal hello; ask one easy question | Start a conversation |
| 2 | Point to the single next step | Reduce overwhelm |
| 3 | Introduce them to one relevant member | Create a connection |
| 5 | Check if they reached the first win | Catch friction early |
| 7 | Invite to the live session / weekly thread | Build the habit |

Keep messages short. One ask per message. No guilt, no fake urgency.

## 4. First 30 days

- **Week 2:** ask what they are working on; reply with one specific resource.
- **Week 3:** ask permission to share their progress as a member story (never invent one).
- **Week 4 (before renewal):** show their progress, state what next month includes, and ask for feedback.

## 5. Activation tracking (simple and honest)

Track a small table in a sheet:

| Member | Joined | First win reached? | Date | Notes |
|---|---|---|---|---|
| | | yes / no | | |

Do **not** report activation as a percentage until you actually have enough members for it to mean anything.
Small samples are anecdotes, not rates.

## 6. Churn-save sequence

Trigger: a member is inactive and their renewal is within 7 days.

1. **Check before you message:** did they reach the first win? If not, the problem is onboarding.
2. **Message:**

   > Hey [name], I noticed you have not had a chance to [first win] yet. Is there something blocking you?
   > If the format is not working for you, tell me honestly — I would rather fix it than have you pay for
   > something that is not useful.

3. **Offer a concrete next step** (a 15-minute call, a smaller task, a different resource).
4. **If they cancel:** no guilt, confirm the end date, ask one question about why. Keep the door open.

## 7. Boundaries to state up front

- Support hours and expected response time.
- What you will and will not do (e.g. no 1:1 coaching on the base tier).
- Refund/cancellation policy in plain language.
- How members can report a problem or a bug.

## 8. Quality bar

- A new member can start in under 5 minutes.
- The first win is achievable within 7 days.
- Every message has one clear ask.
- No fabricated testimonials, member counts, or results.
