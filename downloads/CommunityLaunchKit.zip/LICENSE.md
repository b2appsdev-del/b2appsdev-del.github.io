# License — Paid Community Launch Kit

Copyright (c) 2026. All rights reserved.

## You may

- Use this kit for yourself and inside your own community business.
- Adapt the plan, pricing guide, onboarding sequence and copy templates for your own community or a
  client's community.
- Share printed checklists internally with your team.
- Keep copies for backup.

## You may not

- Resell, sublicense, publish or redistribute this kit, or a lightly edited version of it, as a product.
- Bundle it into another paid product, course or template pack without written permission.
- Claim authorship of the original kit.
- Offer it as a freebie to attract customers.

## Disclaimer

This kit is provided “as is”, without warranty of any kind, express or implied, including fitness for a
particular purpose. It is not financial, legal or tax advice. It does not promise members, revenue or
retention; results depend on your audience, offer and execution. You are responsible for your own pricing,
payments, consumer rules and delivery. The author is not liable for any loss arising from use of this kit.

If you are unsure whether a use is allowed, ask before using it.
