# Page & Listing Copy Templates — Paid Community

Fill the brackets. Examples are labelled and must be replaced with your real details. Never copy an
example as if it were a claim about your community.

## 1. Name and tagline

- Community name: [YOUR COMMUNITY NAME]
- Tagline (≤ 12 words): [WHO IT IS FOR] + [THE OUTCOME]

Example (replace): “A working group for freelance designers who want steady retainer clients.”

## 2. One-sentence promise

> [COMMUNITY NAME] helps [WHO] achieve [OUTCOME] through [FORMAT] without [COMMON FRUSTRATION].

Example (replace): “Helps freelance designers land retainer clients through weekly reviews and templates,
without cold-pitching all day.”

## 3. Page description (150–220 words)

Structure:
1. Who it is for (1 sentence).
2. The problem in their words (2 sentences).
3. What members get (3–5 bullets).
4. The weekly rhythm (1 sentence).
5. What it is not (1 sentence).
6. Price + cancel anytime (1 sentence).

Draft skeleton:

> **[COMMUNITY NAME]** is for [WHO] who want [OUTCOME].
>
> Most [WHO] struggle with [PROBLEM 1] and [PROBLEM 2]. You do not need more information; you need a
> place to do the work with feedback.
>
> **Inside you get**
> - [DELIVERABLE 1]
> - [DELIVERABLE 2]
> - [DELIVERABLE 3]
> - [DELIVERABLE 4]
>
> **Rhythm:** [WHAT HAPPENS WEEKLY].
>
> **What it is not:** [NOT A COURSE / NOT 1:1 COACHING / ETC.].
>
> **Price:** $[X]/month or $[Y]/year. Cancel anytime.

## 4. Benefits (3–5 bullets, outcome-first)

- [Outcome] — [how the community helps].
- [Outcome] — [how].
- [Outcome] — [how].

Example (replace): “A finished portfolio piece every month — from the monthly build task and peer review.”

## 5. Tier copy

| Tier | For | Includes | Price |
|---|---|---|---|
| [Tier 1] | [who] | [3–5 concrete items] | $[X]/mo |
| [Tier 2] | [who] | [Tier 1 + extras] | $[Y]/mo |

Rules: each tier unlocks something concrete; no vague “access to everything”.

## 6. FAQ (answer 6)

1. **Who is this for?** [WHO — and who it is not for.]
2. **What happens after I join?** [First win + onboarding step.]
3. **How much time per week?** [Honest estimate.]
4. **Can I cancel?** [Yes / how / when it stops.]
5. **Do I need [tool/skill]?** [Honest answer.]
6. **Is this a course?** [No — explain format.]

## 7. Launch message (short)

> I am opening **[COMMUNITY NAME]** for [WHO] who want [OUTCOME].
> Inside: [2–3 concrete things] + [weekly rhythm].
> Founding offer: [REAL offer and REAL deadline, or remove this line].
> Details and join: [LINK]. Cancel anytime.

## 8. Reminder message (no fake urgency)

> Quick note: **[COMMUNITY NAME]** is open. If [OUTCOME] is on your list this month, here is what is
> inside and how to start: [LINK]. No pressure — the page explains exactly what you get.

## 9. Honesty checklist before publishing

- [ ] Price matches the checkout exactly.
- [ ] Deliverables match what exists today.
- [ ] No invented testimonials, member counts, or income claims.
- [ ] Deadlines and scarcity are real.
- [ ] Refund/cancellation policy is linked and plain.
- [ ] “Not included” is stated.
