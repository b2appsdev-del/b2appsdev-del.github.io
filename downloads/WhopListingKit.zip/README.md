# Whop Listing Kit

A practical kit for launching a digital product or paid community on Whop: an offline listing-copy builder,
pricing and delivery guides, and a 20-item launch checklist.

## What is inside

| File | Purpose |
|---|---|
| `index.html` | Listing copy builder (titles, short/long description, FAQ, copy button) + interactive checklist |
| `LISTING-COPY.md` | Listing anatomy, title formulas, short/long structure, FAQ bank, honest before/after |
| `PRICING.md` | Tier selection, honest anchoring, fee math, refunds, testing without lying |
| `DELIVERY.md` | Download vs community access, post-purchase message, troubleshooting |
| `LAUNCH-CHECKLIST.md` | Printable checklist including a real test purchase |
| `LICENSE.md` | Usage terms |

## Quick start (30 minutes)

1. Open `index.html` → fill the builder fields → **Generate draft**.
2. Copy the draft into your listing; edit it in your own voice.
3. Read `PRICING.md` and set the price before touching the copy again.
4. Follow `LAUNCH-CHECKLIST.md`; do not announce until the test purchase delivers.
5. Use `DELIVERY.md` for the post-purchase message and access troubleshooting.

Everything works offline in a modern browser. No account, no network, no tracking — your draft stays in your
browser's local storage.

## Scope and honesty

- **Independent product.** Not affiliated with, endorsed by or sponsored by Whop.
- Platform features, fees and policies change; check the current documentation before launch.
- No guarantee of approval, traffic, sales or income.
- Copy templates are starting points: every claim you publish must be true for your product.

## License

Personal use by the buyer and inside the buyer's own business; no resale or redistribution. See `LICENSE.md`.

## Support

Self-serve digital product. For purchase or delivery issues, use the marketplace support channel where you
bought it. For product questions, use the seller address on the listing.
