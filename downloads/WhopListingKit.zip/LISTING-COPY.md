# Listing Copy — Structure That Works

Use `index.html` to generate a first draft from your inputs, then edit it. This file explains why each part
exists and how to keep it honest.

> Not affiliated with Whop. Platform fields, limits and policies change — check the current docs before you
> finalize a listing.

## The order buyers read in

1. **Title** — what it is + the outcome. One line.
2. **Short description** — who it is for, what they get, format, price. No adjectives doing the work of facts.
3. **Cover + screenshots** — show the real artifact.
4. **Long description** — problem → what it is → what's inside → who it's for → what it's not → price/delivery.
5. **FAQ** — format, delivery, refunds, scope.
6. **Checkout** — price matches, delivery tested.

## Title formulas

| Formula | Example |
|---|---|
| Name — outcome | Freelance Cashflow Sheet — See 12 Months Ahead |
| Name for audience | Freelance Cashflow Sheet for Irregular Income |
| Name: format + access | Freelance Cashflow Sheet: Spreadsheet Kit · Instant Access |

Avoid: “Ultimate”, “#1”, “Secret”, “Passive income”, “Guaranteed”, invented numbers. They attract refunds and
erode trust.

## Short description

One or two sentences, 160 characters or fewer when the field allows:

> `<Product>` helps `<audience>` `<outcome>`. `<Format>` · `<delivery>` · `$<price>`.

Rules:
- The outcome must be something the product actually enables.
- Mention the format (spreadsheet, guide, community) so expectations are set.
- Price in the short description reduces surprise clicks and refunds.

## Long description skeleton

```
[Problem] If you are <audience>, <specific problem>.
[What it is] <Product> is a <format> that helps you <outcome>.
[Inside]     • item 1  • item 2  • item 3  (only real contents)
[Who]        Built for <audience>.
[Not]        <One honest limitation>. Not affiliated with Whop.
[Price]      $<price> · one-time · <delivery>.
[CTA]        Get <product> — $<price>
```

## Bullet writing

- Start with a noun the buyer can hold: “12-month cashflow sheet”, not “powerful insights”.
- One benefit per bullet, maximum six.
- If you write a number, verify it against the ZIP.
- Link a bullet to a screenshot when possible.

## FAQ bank

Use 3–5. Keep answers short and factual.

- **What exactly do I get?** List the files/access.
- **How is it delivered?** Instant download / community invite / both; mention where to find it.
- **What do I need to use it?** App, browser, basic skill level.
- **Refunds?** Point to the checkout policy; do not invent a policy that contradicts it.
- **Is this for beginners?** Answer honestly.
- **Is this affiliated with Whop?** No — independent product; Whop is the checkout platform.
- **Can I resell it?** State your license plainly.

## Before/after example (honest edit)

Weak:
> The ultimate cashflow system that will transform your freelance business forever!

Better:
> A 12-month cashflow sheet for freelancers with irregular income. Track invoices, due dates and late payments
> in one place. Spreadsheet + templates; $19; instant download. Not accounting software.

The second is more specific, more believable and easier to buy.
