# Whop Listing Kit — Launch Checklist (printable)

Tick every line before you announce. The interactive version is in `index.html` (saved in your browser).

## Product

- [ ] W01 · Product is finished and matches the files you will deliver
- [ ] W02 · Price decided before copy; identical on listing, checkout and delivery message
- [ ] W03 · Who it is for and the problem are clear in the first two lines
- [ ] W04 · Short description fits the field and reads cleanly without hype
- [ ] W05 · Every “what's inside” bullet is literally in the deliverable
- [ ] W06 · One honest limitation is stated visibly
- [ ] W07 · No fake reviews, numbers, scarcity or unverifiable claims

## Listing page

- [ ] W08 · Cover image and 2+ screenshots show the actual product
- [ ] W09 · Checkout price, currency and product name verified on the live page
- [ ] W15 · FAQ covers format, delivery, refunds and scope
- [ ] W17 · Mobile view: title, price and buy button visible without zoom
- [ ] W18 · Desktop view: no broken images or overlapping text
- [ ] W19 · Listing opened in a private window (not logged in as owner)

## Purchase and delivery

- [ ] W10 · Real test purchase completed with your own card/crypto (small amount)
- [ ] W11 · After purchase: files download and open, or community access works
- [ ] W12 · Delivery message includes access steps and support contact
- [ ] W13 · Refund/terms line visible before purchase and consistent with policy
- [ ] W14 · Crypto (if enabled) tested with a small amount; network/memo noted
- [ ] W16 · Support email monitored; response expectation stated or implied

## Safety net

- [ ] W20 · You can unpublish or change the product quickly if something breaks

## After launch (first 48 hours)

- [ ] Check the listing renders for logged-out visitors
- [ ] Confirm the first real order delivered automatically
- [ ] Log questions buyers ask; update the FAQ from real questions
- [ ] Fix broken links or typos immediately; note the change date
- [ ] Do not add fake reviews or bought engagement to “get started”

## Record

| Date | Tester | Checkout method | Result | Notes |
|---|---|---|---|---|
|  |  |  |  |  |
