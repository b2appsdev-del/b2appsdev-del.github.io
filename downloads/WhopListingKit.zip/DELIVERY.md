# Delivery — Files, Access and the Post-Purchase Message

A purchase is not complete when the payment clears. It is complete when the buyer has the product and knows
how to use it.

> Platform options change. Verify file size limits, file hosting and access controls in the current docs.

## 1. Choose the delivery type

| Type | Use when | Check before launch |
|---|---|---|
| Instant download | One-off digital files | File opens, size is small, license included |
| Private community access | Ongoing support/updates | Invite works, roles are correct, no dead links |
| Download + community | Kit plus a place for questions | Both of the above |

## 2. Package the files

- Name the ZIP after the product: `ProductName.zip`, version inside (`v1.0` in README).
- Include: README (what it is + how to start), license, the actual assets.
- No personal files, no build junk, no stray screenshots with secrets.
- Test on a clean machine or a fresh profile; unzip and open every file.

## 3. The post-purchase message

Keep it short and useful:

```
Thanks for buying <product>.

Start here:
1. Unzip <file> and open README.md (or index.html).
2. <First concrete action, 10 minutes>.
3. If anything is missing or broken, reply to this message or email <support>.

License: personal use; no resale. Refunds: <platform policy or your line>.
```

Avoid: asking for a review before delivery, upsell walls, or claiming access that is not actually ready.

## 4. Access troubleshooting

| Symptom | Check |
|---|---|
| Buyer cannot download | File attached to the product, not just linked in the description |
| Community shows as locked | Role/tier mapped to the product; invite accepted |
| Buyer got the wrong tier | Tier names and contents match the listing |
| Buyer cannot find the download | Delivery message includes the exact location and a direct path |
| Crypto payment pending | Delivery should start after confirmation per your policy — state it clearly |

## 5. Updates

- Keep a changelog in the product folder.
- When you update files, note the version and date in the delivery message.
- If an update breaks something, tell buyers; do not silently replace files.

## 6. Support boundaries

State what you support (product usage and missing files) and what you do not (custom work, tooling setup,
financial or legal advice). A clear boundary prevents most disputes.

## 7. Before you announce

- [ ] Test purchase completed, delivery received
- [ ] Files unzip and open on a clean profile
- [ ] Community access verified with a non-owner account (if applicable)
- [ ] Delivery message sent automatically or manually, tested
- [ ] Support address monitored
- [ ] Refund line visible and consistent with the platform
