# Pricing — Without Fake Urgency

> Fee percentages and payout options change. Check the current Whop documentation and your own checkout page;
> this guide deliberately avoids quoting rates that go stale.

## 1. Pick a number you can defend

Answer three questions:

1. What does the buyer replace? (hours, a tool subscription, a freelancer task)
2. What is the smallest useful version? Price that, not the future roadmap.
3. What is your delivery cost? (payment fees, support time, platform costs)

If the honest answer is “a few dollars of value”, price it low and small — or make a bigger product.

## 2. Tiers

| Tier | Use when | Risk |
|---|---|---|
| Entry ($9–19) | First product, low support, instant download | Attracts price-sensitive buyers; keep scope tight |
| Core ($24–49) | Complete kit with templates + process | Must clearly beat the entry tier |
| Pro ($79+) | Adds review, setup help or updates | Support load rises; be explicit about what is included |

One tier is fine for a first launch. Two tiers work when the upgrade is obvious (e.g. kit vs kit + 1:1 setup).

## 3. Anchoring honestly

- Show the contents, not a crossed-out fake price.
- “Was $49, now $19” is only honest if it was actually sold at $49.
- A real launch discount is fine: state the end date and honor it.
- Never fake scarcity (“3 spots left”) unless the limit is real and enforced.

## 4. Fees and net revenue

Before choosing a price, open your platform's current fee page and your payment provider's page, then compute:

```
net = price − platform fee − payment/processing fee − payout fee (if any)
```

Write the result in your own notes. Do not copy fee numbers from this kit into your listing — they will age.

## 5. Refunds

- Read the platform's buyer policy and your local obligations.
- Put a short, clear line in the listing: what is refundable and what is not (e.g. digital downloads after
  access), without contradicting the platform.
- Honor what you wrote. A cheap sale is not worth a public dispute.

## 6. Price testing without lying

- Change price between cohorts, not mid-checkout.
- Keep the product identical during a test, or you learn nothing.
- Record date, price, traffic source and sales count; small samples are noisy — do not overinterpret.
- A lower price is not a strategy if delivery and copy are unclear.

## 7. When to raise the price

- Support questions repeat the same missing piece → add it, then raise.
- The kit now includes more real assets than the listing promises → update the listing, then the price.
- You are selling consistently and delivery is smooth → test a higher tier.

Do not raise the price during an active discount you promised to honor.
