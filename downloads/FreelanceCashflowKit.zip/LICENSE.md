# License — Freelance Cashflow Kit

Copyright © 2026 the seller. All rights reserved.

## Granted

- Personal use by the buyer.
- Use inside the buyer's own freelance business or studio.
- Editing the file for the buyer's own use.
- Printing and storing copies for the buyer's own records.

## Not granted

- Resale, sublicensing, redistribution or publication of this kit or a derivative as a product, template pack or
  free download.
- Sharing the files with clients, other freelancers or the public.
- Removing copyright and presenting the kit as one's own product.

## No warranty

Provided “as is”, without warranty of any kind. The seller is not liable for financial decisions, missed
payments, tax outcomes or losses arising from use of the tracker. Figures are user-entered; verify them against
your bank and invoices, and consult a qualified accountant for tax matters.
