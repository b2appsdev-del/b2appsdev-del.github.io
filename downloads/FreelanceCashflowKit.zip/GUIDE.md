# 10-Minute Guide

## 1. Set the frame (1 minute)

Open `index.html`. In **Setup**, pick your currency, enter your current balance, the percentage you set aside for
tax, your monthly fixed costs, and the first month of the view.

> The tax percentage is your decision, not a recommendation. Use what your accountant tells you.

## 2. Add open and paid invoices (3 minutes)

For each invoice: client, amount, issue date, due date. Tick “paid” and set the paid date when money actually
arrives. Status is automatic:

- **Paid** — the box is ticked.
- **Overdue** — unpaid and the due date is before today.
- **Pending** — unpaid and not yet due.

## 3. Log expenses (2 minutes)

One row per one-off cost, with the month it belongs to. Fixed monthly costs from Setup are added to every month
automatically, so do not log rent or subscriptions again.

## 4. Read the 12-month table (2 minutes)

- **Invoiced** — what you billed that month, whether paid or not.
- **Received** — paid dates in that month.
- **Expenses** — logged expenses + fixed costs.
- **Tax reserve** — received × your percentage.
- **Net** — received − expenses − tax reserve.
- **Balance** — running total from your starting balance.

A negative month says “negative” in words, not just colour.

## 5. Monthly routine (2 minutes)

1. Add new invoices; tick the ones that got paid.
2. Log last month’s one-off expenses.
3. Check the next three months for negative balances.
4. Download the CSV and send it to your accountant.

## What this is not

Not accounting software, not tax advice, no bank connection, no currency conversion. If the numbers matter,
reconcile them against your bank and invoices.
