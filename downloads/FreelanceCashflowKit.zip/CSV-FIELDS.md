# CSV field reference

The export is one `.csv` file with four sections separated by blank lines. Numbers are plain decimals (no
currency symbol) and rounded to two places.

## Header

| Field | Meaning |
|---|---|
| `Generated` | Export date (YYYY-MM-DD) |
| `Currency` | USD / EUR / GBP (symbol only) |
| `Starting balance` | Value from Setup |
| `Tax reserve %` | Percentage used for the reserve |
| `Monthly fixed costs` | Added to every month in the view |

## Invoices

| Column | Meaning |
|---|---|
| `client` | Invoice client |
| `amount` | Billed amount |
| `issued` | Issue date |
| `due` | Due date |
| `status` | `paid`, `overdue` or `pending` at export time |
| `paid_date` | Date marked paid, empty if unpaid |

## Expenses

| Column | Meaning |
|---|---|
| `month` | Month the cost belongs to |
| `category` | Free-text category |
| `amount` | Cost |
| `note` | Optional note |

## Monthly cashflow

| Column | Meaning |
|---|---|
| `month` | YYYY-MM |
| `invoiced` | Invoices issued in the month |
| `received` | Invoices with a paid date in the month |
| `expenses` | Logged expenses + fixed costs |
| `tax_reserve` | received × tax % |
| `net` | received − expenses − tax_reserve |
| `balance` | Running balance |

The final row is `TOTAL` (balance = last month’s balance). Spreadsheet apps may parse the `%` in the header as a
formula character only if you paste it into a formula cell; opening the file normally is fine.
