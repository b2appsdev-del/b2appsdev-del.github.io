# Freelance Cashflow Kit

An offline single-file tracker for solo freelancers: invoices with automatic paid/overdue status, an expense log,
a 12-month cashflow with running balance and a tax reserve you set, plus CSV export for your accountant.

Open `index.html` in any modern browser. No account, no install, no network requests. Your data stays in that
browser’s local storage.

## Files

| File | Purpose |
|---|---|
| `index.html` | The tracker |
| `GUIDE.md` | Ten-minute setup and monthly routine |
| `CSV-FIELDS.md` | Export column reference |
| `LICENSE.md` | Usage terms |

## What it does

- Invoices: client, amount, issue/due dates, paid flag; status derived (paid / overdue / pending).
- Expenses: per-month one-off costs; fixed monthly costs handled in Setup.
- 12-month view: invoiced, received, expenses, tax reserve, net, running balance.
- KPIs: invoiced, received, outstanding, overdue amount and count.
- CSV export and print/PDF.
- Sample data button to see how it works before entering real numbers.

## What it does not do

- It is not accounting software and does not provide tax advice.
- No bank sync, no invoice sending, no currency conversion, no payment processing.
- It stores data in one browser only; clearing browser data removes it. Export a CSV for backups.
- Currency is a display symbol only; all amounts are treated as the same currency.

## Support

Self-serve digital product. For purchase or delivery issues, use the marketplace support channel where you
bought it.
