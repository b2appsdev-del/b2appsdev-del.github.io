# Moderator Macros

Copy-ready messages for the situations that actually come up. Replace `#channel`, `#rule` and email addresses.
Keep them short, name the behaviour, state the next step, and avoid sarcasm.

## Warning

**M01 — First off-topic nudge**
> Quick nudge: this post is off-topic for `#channel`. Please move it to `#relevant` or take it to DMs. No action
> taken.

**M02 — Second reminder, tone**
> This is the second reminder on tone. Disagree with the argument, not the person. Next step is a short mute so
> the thread can cool down.

## Spam

**M03 — Promo removed**
> I removed the promo post. Self-promo is allowed once in `#promo` with context; repeated posting here leads to a
> mute.

**M04 — Unsolicited DMs**
> Unsolicited DMs to members are not allowed. If someone asked for your offer, reply in the thread or in `#promo`.

**M05 — Undisclosed affiliate link**
> Affiliate links need disclosure and belong in `#promo`. I removed the link; you are welcome to repost it there
> with the disclosure.

## Conflict

**M06 — Thread pause**
> Pausing this thread for an hour. Both sides have made their point; restate it once, without the personal
> comments, and I will reopen.

**M07 — Pile-on stop**
> No pile-ons. If you have a problem with a member, message a mod instead of tagging others in. Further pile-on
> posts will be removed.

**M08 — Take it elsewhere**
> Take the disagreement to DMs or a separate thread. The main channel is for the topic, not the argument about
> the argument.

## Privacy

**M09 — Personal details removed**
> I removed the personal details. Please do not post names, addresses, emails or handles without consent. Repost
> without them.

**M10 — Private screenshot**
> Screenshots of private conversations need consent from everyone in them. Please delete it; a summary is fine.

## Off-topic

**M11 — Wrong channel**
> Wrong channel: this belongs in `#channel`. I will leave it up for an hour, then move it.

**M12 — Duplicate**
> This is a duplicate of an existing thread. Please continue there so answers stay in one place.

## Access

**M13 — Refund/billing redirect**
> Refund and billing questions go to support@example.com, not the community. I am closing this thread so it does
> not turn into a public dispute; support will reply directly.

**M14 — Role/access request**
> Role or access request received. I will check the purchase record and update your access today. Please do not
> share receipts in the channel.

## Ban

**M15 — Temporary mute**
> You are muted for 24 hours after repeated warnings about `#rule`. The mute lifts automatically; use the time to
> read the rules.

**M16 — Removal with appeal path**
> You have been removed for repeated violations of `#rule` after warnings. To appeal, email appeals@example.com
> with your handle and what happened.

## Writing your own macro

1. Start with the specific behaviour, not “you are being a problem”.
2. One sentence on why it matters; one on what happens next.
3. State the next step and, for mutes, the duration.
4. No CAPS, no sarcasm, no public shaming.
5. Link the rule instead of arguing it in the thread.
