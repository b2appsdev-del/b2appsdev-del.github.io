# Community Moderation Pack

Rules a member can read in three minutes, an escalation ladder, 16 copy-ready moderator messages, and a private
incident log with CSV export.

Open `index.html` in any modern browser. Offline, no account, no telemetry.

## Files

| File | Purpose |
|---|---|
| `index.html` | Rules generator, 16 macros with filter/search/copy, incident log + CSV |
| `RULES-TEMPLATE.md` | Editable rules and design notes |
| `ESCALATION-PLAYBOOK.md` | Ladder, timing, serious incidents, handover |
| `MOD-MACROS.md` | Full text of every macro and how to write new ones |
| `README.md` | This file |
| `LICENSE.md` | Usage terms |

## Workflow

1. Generate the rules with your community name, purpose, platform and appeals email.
2. Edit for tone and post where new members land.
3. Keep the pack open while moderating; copy the macro that fits the lowest escalation step.
4. Log the incident privately (severity, action, date, minimal notes).
5. Export the CSV before a break or handover, then keep it private.

## What it does not do

- It does not connect to Discord/Whop/Circle or perform moderation actions.
- It does not send, schedule or automate messages.
- It does not verify reports or decide who is telling the truth.
- It does not provide legal advice or guarantee platform compliance.

## Principles

- Rules protect members, not the owner's comfort. Criticism and refund questions are not violations by default.
- Same behaviour, same response. Record decisions so a second moderator can reproduce them.
- Keep private data out of public threads and out of the log unless needed.
- Do not use moderation to win arguments.

## Support

Self-serve digital product. For purchase or delivery issues, use the marketplace support channel where you
bought it.
