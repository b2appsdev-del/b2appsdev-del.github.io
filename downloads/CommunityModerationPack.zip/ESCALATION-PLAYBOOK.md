# Escalation Playbook

The same behaviour should get the same response, whoever the member is. Pick the lowest step that fits, record
what you did, and move on.

## The ladder

| Step | When | What you do | Record |
|---|---|---|---|
| 1. Ignore / absorb | Good-faith mistake, no harm | Nothing public; fix quietly if needed | Nothing, or a note |
| 2. Reminder | Off-topic, mild tone issue, accidental promo | Public macro (M01, M11) or a DM | Optional |
| 3. Content removal | Spam, private info, duplicate, affiliate link | Remove/hide + macro (M03, M09) | Yes |
| 4. Warning | Second instance, or first real harm | Private macro (M02, M04) + link to rules | Yes |
| 5. Cool-down / mute | Conflict heating up, repeated warnings ignored | Temporarily lock thread or mute (M06, M15) | Yes |
| 6. Removal | Harassment, doxxing, ban evasion, threats | Remove from community (M16) | Yes |
| 7. Review | Appeal, or a decision you are unsure about | Second moderator reviews; reply with outcome | Yes |

## Timing

- Reminder: same day.
- Removal of private data or spam: within the hour where possible.
- Mute: state the duration and how it ends; do not leave it indefinite.
- Appeal: acknowledge within 48 hours, even if the answer is “no”.

## Who decides

- One moderator handles steps 1–4.
- Removal needs a second moderator where available, or a written reason from the owner.
- The person who removed a member should not also decide the appeal if anyone else can.

## Serious incidents (harassment, threats, doxxing)

1. Preserve evidence privately (screenshot to the private log, not the channel).
2. Remove the content and, where warranted, the member immediately.
3. Check whether the target needs support or a check-in.
4. Do not debate the decision in public. Post a short neutral note if the channel saw it.
5. Escalate to platform reporting or law enforcement if there is a credible threat.

## Paid communities and refund disputes

- Move the conversation to support email immediately; do not argue about entitlement in public.
- Never post purchase or payment details in the community.
- Log the outcome; repeated demands to litigate refunds publicly are a moderation issue, not a reason to shame
  the member.

## Handover

Before a break or a new moderator:

- Export the incident CSV and write a one-paragraph summary of open cases.
- List decisions pending appeal, with dates.
- Note any member under a mute and when it ends.

## What not to do

- Do not moderate while angry; hand over or wait an hour.
- Do not use warnings as a threat you never carry out.
- Do not remove criticism of the product as if it were harassment.
- Do not share member data or incident notes outside the mod team.
