# License — Community Moderation Pack

Copyright © 2026 the seller. All rights reserved.

## Granted

- Personal use by the buyer.
- Use inside the buyer's own community or the communities the buyer moderates.
- Editing the rules, macros and playbook for the buyer's own use.
- Printing and storing copies for the buyer's own team.

## Not granted

- Resale, sublicensing, redistribution or publication of this pack or a derivative as a product or free download.
- Sharing the files with other communities or the public.
- Removing copyright and presenting the pack as one's own product.

## No warranty; no legal advice

Provided “as is”, without warranty of any kind. The seller is not a lawyer and does not provide legal advice.
Rules, escalation and consent text are starting points that must be adapted to the buyer's platform and
jurisdiction. The seller is not liable for moderation decisions, complaints, removals or losses arising from use
of the pack.
