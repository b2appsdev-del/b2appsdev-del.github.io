# Rules Template

Replace `[brackets]`. Read the result aloud; if a sentence needs explaining, shorten it. Publish where new members
land and link it in the welcome message.

> Starting point, not legal advice. Platform rules and local law still apply.

## [Community name] — Rules

**Platform:** [Discord / Whop / Circle / Slack / Telegram]
**Purpose:** a place for [what the community is for].

We moderate to keep this useful for everyone. Most issues start with a reminder; repeated or serious issues lead
to a mute, then removal. Context matters, but the same behaviour gets the same response.

1. **Respect people, not just opinions.** No harassment, slurs, threats or targeted mockery.
2. **No spam or unsolicited DMs.** Promotion belongs in [channel], once, with context.
3. **Keep advice honest.** No guaranteed financial, medical or legal outcomes; disclose affiliations.
4. **Protect privacy.** No doxxing, and no screenshots of private conversations without consent.
5. **Argue the point, not the person.** No pile-ons and no tagging people in to fight.
6. **One account per person.** No ban evasion or impersonation.
7. **Stay on topic in each channel;** use the channel that fits the post.
8. **Follow platform rules and the law,** including refund and consumer rules.

**Enforcement:** first a reminder or content removal; repeated or serious issues lead to a mute, then removal.

**Appeals:** email [appeals email] with your handle, what happened, and the date.

**Privacy:** do not repost private conversations, personal details or payment receipts. Moderation records are
kept private.

## Design notes

- Keep the list to 8–10 rules. Long lists are not read and not enforced consistently.
- Name the behaviour, not the type of person: “no unsolicited DMs” beats “no bad actors”.
- Separate “no spam” from “no criticism”. Criticism of the product is allowed; harassment is not.
- Put refund and billing questions in a dedicated support path; do not litigate them in public channels.
- Do not write rules that only protect the owner. Members notice, and enforcement becomes a fight.
- Version the rules with a date. Announce material changes; do not apply them retroactively.
- Add a one-line “what happens next” to each serious rule. Uncertainty invites testing.

## Enforcement sentence options

- Calm: “Most issues start with a reminder; we escalate when the same behaviour continues.”
- Firm: “We apply these rules consistently. Repeated issues lead to a mute, then removal.”
- Paid community: add “Access and refund questions go to [support email]; the community is not the support desk.”

## What not to include

- “We can remove anyone for any reason” unless your lawyer has confirmed that is enforceable where you sell.
- Rules banning all disagreement, or requiring positivity.
- Threats that you cannot carry out, or punishments you cannot administer on the platform.
- Personal data requests that go beyond what you need to verify access.
