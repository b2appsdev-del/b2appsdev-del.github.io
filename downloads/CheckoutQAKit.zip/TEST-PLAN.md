# Crypto Checkout QA — Test Plan

Version 1.0 · Part of the **Crypto Checkout QA Kit** · Companion to `index.html` and `REPORT-TEMPLATE.md`

> Run these tests on a **staging** checkout with small amounts. Never test payment edge cases against
> live customer orders. Record evidence (transaction hash, screenshot, webhook log line) for every case.

## 1. Scope

In scope: order creation → payment → confirmation → fulfilment, plus refunds and reconciliation for a
checkout that accepts crypto (hosted checkout, payment API, or manual invoices).

Out of scope: smart-contract auditing, custody/security review of your wallet, tax and legal advice.

## 2. Environment checklist (fill before testing)

| Item | Value |
|---|---|
| Checkout / provider | ______________________________ |
| Staging URL | ______________________________ |
| Test order amount (small) | ______________________________ |
| Networks accepted | ______________________________ |
| Required confirmations per asset | ______________________________ |
| Webhook endpoint + log location | ______________________________ |
| Refund method | ______________________________ |
| Tester + date | ______________________________ |

## 3. Severity guide

- **High** — can lose money or silently mis-credit an order; must fix before launch.
- **Medium** — confusing or recoverable with manual work; fix or document a workaround.
- **Low** — cosmetic or messaging issue; can ship and improve.

## 4. Test cases

### T01 — Exact amount, correct network (happy path)
- **Steps:** create a test order; pay the exact quoted amount on the expected network; wait for the required confirmations.
- **Expected:** order becomes paid exactly at the threshold; fulfilment fires once; customer sees confirmation.
- **Severity:** High

### T02 — QR / wallet scan
- **Steps:** open the payment QR in a wallet; check the network and asset shown before sending; send.
- **Expected:** wallet shows the same network/asset as the invoice; payment matches the order.
- **Severity:** High

### T03 — Pending state is honest
- **Steps:** pay and inspect the order screen while confirmations are below the threshold.
- **Expected:** UI says “awaiting confirmations” (with a count if available); it never says “paid” early.
- **Severity:** High

### T04 — Underpayment
- **Steps:** send slightly less than quoted (e.g. deduct a network fee).
- **Expected:** order is partial/unpaid, not fulfilled; customer is told the shortfall and the next step.
- **Severity:** High

### T05 — Overpayment
- **Steps:** send more than quoted.
- **Expected:** documented behaviour (credit, manual refund, or accepted); surplus is visible in the order log.
- **Severity:** Medium

### T06 — Wrong network
- **Steps:** pay an invoice for a multi-chain asset on a different chain (for example TRC-20 instead of ERC-20).
- **Expected:** order does **not** auto-credit; it is flagged for manual review; customer receives recovery instructions.
- **Severity:** High

### T07 — Missing or wrong memo/tag
- **Steps:** for a memo-based asset, send with a wrong or missing memo/tag.
- **Expected:** order is flagged, not silently credited to the wrong account; support path is clear.
- **Severity:** High

### T08 — Expired quote / rate drift
- **Steps:** let the quote expire, then pay the old amount.
- **Expected:** customer is asked to refresh the quote; order is not under-credited silently.
- **Severity:** Medium

### T09 — Reorg / dropped transaction
- **Steps:** simulate (or use a provider sandbox for) a transaction that loses confirmations.
- **Expected:** order can return to pending; no double credit; final state matches the chain.
- **Severity:** High

### T10 — Duplicate webhook
- **Steps:** replay the same “paid” webhook 3–5 times.
- **Expected:** idempotent handling — one fulfilment, one credit, duplicates logged and ignored.
- **Severity:** High

### T11 — Out-of-order webhook
- **Steps:** deliver “paid” before “created” (and the reverse).
- **Expected:** final state is still correct; no lost events.
- **Severity:** Medium

### T12 — Invalid signature / spoofed webhook
- **Steps:** send a webhook with a bad signature.
- **Expected:** rejected with an error, logged; no state change.
- **Severity:** High

### T13 — Webhook outage
- **Steps:** disable your endpoint, pay, then re-enable it.
- **Expected:** a retry or reconciliation job recovers the order within a known window.
- **Severity:** High

### T14 — Refund as a new payment
- **Steps:** refund a paid order.
- **Expected:** an outgoing transaction is sent to a customer-confirmed address; hash, network, amount and reason are logged; order shows refunded.
- **Severity:** High

### T15 — Double payment by customer
- **Steps:** pay the same order twice.
- **Expected:** one fulfilment; the second payment is detected and queued for refund.
- **Severity:** High

### T16 — Invoice reuse / address collision
- **Steps:** create two orders for the same amount and pay both.
- **Expected:** each payment maps to its own order; no cross-credit even with identical amounts.
- **Severity:** High

## 5. Exit criteria

- All **High** cases pass, or every failure has a documented manual workaround and an owner.
- Every test has an evidence artifact linked in the report.
- The incident runbook steps have been read by whoever handles support.
- A novice can complete T01 using only this kit and the checkout UI.

## 6. Reconciliation log (use for refunds and exceptions)

| Date | Order ID | Direction | Asset / network | Amount | Tx hash | Reason | Status |
|---|---|---|---|---|---|---|---|
| | | in / out | | | | | |

## 7. After launch

Re-run T01–T04 and T10–T14 whenever you change: payment provider, accepted networks, confirmation
thresholds, webhook code, pricing logic, or refund policy. Keep the last report with the launch notes.
