# Crypto Checkout QA Kit

A practical kit for stores that accept crypto: a test plan, an interactive checklist, an incident
runbook and a report template. Purpose: catch the failures that quietly lose money — stuck
confirmations, wrong network or memo, under/overpayment, duplicate webhooks, and refunds.

Offline. Single HTML file. No signup, no tracking, no external requests.

## What's inside

| File | Use it for |
|---|---|
| `index.html` | Start here. How-to, network/memo matrix, interactive checklist, incident runbook, license |
| `TEST-PLAN.md` | 16 test cases with steps, expected results and severity |
| `REPORT-TEMPLATE.md` | Record outcomes and findings; copy per run |
| `README.md` | This file |
| `LICENSE.md` | Personal-use license and disclaimer |

## Quick start (5 minutes)

1. Unzip the folder somewhere you can keep it.
2. Open `index.html` in any modern browser. Everything works offline.
3. Read “How to use this kit” and fill in your provider details in `TEST-PLAN.md` → section 2.
4. Run `T01` first on staging. If the happy path does not work, stop and fix it before the edge cases.
5. Tick cases in `index.html` as you go; your ticks save in that browser. Copy results into
   `REPORT-TEMPLATE.md` when done.
6. Print the checklist with the “Print checklist” button if you prefer paper.

## How to adapt it

- Replace the “Your provider's rule” column with the real rules for the networks you accept.
- Add or remove test cases for assets you do not support.
- Keep the severity levels: anything that can lose money or silently mis-credit an order is High.
- Re-run the relevant cases after any change to provider, networks, confirmations, webhooks or refunds.

## What this is not

- Not financial, security or legal advice.
- Not a guarantee that a payment provider behaves correctly. It verifies **your** integration against
  known failure modes.
- Not a smart-contract audit or a wallet-security review.

Crypto payments are usually irreversible. Always test with small amounts on staging first.

## License

See `LICENSE.md`: personal use by the buyer and inside the buyer's own business; **no resale or
redistribution** of the kit itself.
