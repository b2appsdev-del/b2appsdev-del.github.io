# License — Crypto Checkout QA Kit

Copyright (c) 2026. All rights reserved.

## You may

- Use this kit for yourself and inside your own business.
- Adapt the test plan, checklist, report template and runbook for your own store or for a client's store.
- Share the printed checklist internally with your team.
- Keep copies for backup.

## You may not

- Resell, sublicense, publish or redistribute this kit, or a lightly edited version of it, as a product.
- Bundle it into another paid product, course or template pack without written permission.
- Claim authorship of the original kit.
- Provide it as a downloadable freebie to attract customers.

## Disclaimer

This kit is provided “as is”, without warranty of any kind, express or implied, including fitness for a
particular purpose. It is not financial, security, tax or legal advice. Crypto payments are often
irreversible, and testing is not a guarantee against loss. You are responsible for your own checkout,
wallets, compliance and testing. The author is not liable for any loss arising from use of this kit.

If you are unsure whether a use is allowed, ask before using it.
