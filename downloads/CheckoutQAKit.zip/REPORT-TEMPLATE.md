# Crypto Checkout QA — Report Template

Copy this file per test run. Do not edit the original.

## Run summary

| Field | Value |
|---|---|
| Date | ____________________ |
| Tester | ____________________ |
| Product / checkout version | ____________________ |
| Provider | ____________________ |
| Environment (staging / live) | ____________________ |
| Assets & networks tested | ____________________ |
| Overall verdict | PASS / PASS WITH CAVEATS / FAIL |

## Results

| Case | Description | Result (Pass / Fail / Blocked) | Evidence (hash, screenshot, log) | Notes |
|---|---|---|---|---|
| T01 | Exact amount, correct network | | | |
| T02 | QR / wallet scan | | | |
| T03 | Pending state is honest | | | |
| T04 | Underpayment | | | |
| T05 | Overpayment | | | |
| T06 | Wrong network | | | |
| T07 | Missing or wrong memo/tag | | | |
| T08 | Expired quote / rate drift | | | |
| T09 | Reorg / dropped transaction | | | |
| T10 | Duplicate webhook | | | |
| T11 | Out-of-order webhook | | | |
| T12 | Invalid signature / spoof | | | |
| T13 | Webhook outage | | | |
| T14 | Refund as a new payment | | | |
| T15 | Double payment | | | |
| T16 | Invoice reuse / address collision | | | |

## Findings

### High severity
| # | Case | What happened | Impact | Owner | Status |
|---|---|---|---|---|---|
| 1 | | | | | |

### Medium severity
| # | Case | What happened | Workaround | Owner | Status |
|---|---|---|---|---|---|
| 1 | | | | | |

### Low severity
| # | Case | What happened | Suggested fix |
|---|---|---|---|
| 1 | | | |

## Sign-off

- [ ] All High cases pass, or each has a documented workaround and an owner.
- [ ] Evidence linked for every executed case.
- [ ] Support team has the incident runbook and status templates.
- [ ] Reconciliation log started for refunds and exceptions.

Tested by: ____________________  Date: ____________

Approved by: ____________________  Date: ____________
